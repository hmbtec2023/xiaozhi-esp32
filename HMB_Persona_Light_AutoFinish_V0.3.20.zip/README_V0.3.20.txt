HMB|TEC Persona Light V0.3.20 – EXPERIMENTAL AUTO-FINISH
Base: uploaded V0.3.18 CLEAN. No camera/SSCMA changes.

Modified:
- main/boards/sensecap-watcher/sensecap_watcher.cc
- main/boards/sensecap-watcher/persona_version.h

After successful set_light_scene MCP callback, monitor the XiaoZhi device state.
After 1s, issue the existing ToggleChatState event once in Speaking
(abort), and once in Listening (close audio channel), if reached.
Never issue toggle in Idle; never force Idle. 15s diagnostic timeout.

WARNING: experimental, not compiled/tested against the full firmware tree.
The state can change between observing it and event processing. Verify on
hardware. Preserve V0.3.18 rollback.

Install from project root:
 unzip -o HMB_Persona_Light_AutoFinish_V0.3.20.zip 'main/*'
 idf.py build
 grep -aob 'V0.3.20' build/xiaozhi.bin
 idf.py -p /dev/cu.usbmodem5A8A0534903 flash
