HMB|TEC Persona Light V0.3.21 (SOURCE PATCH, UNTESTED)

- Async-safe Persona finish: guarded dispatch in application.cc; no accidental idle->new chat.
- MCP duplicates do not restart finish within the same detection cycle.
- Rearm requires fresh negative SSCMA frames for 10 seconds while Idle; paused/stale frames do not count as absence.
- No changes to SSCMA driver, MCP parameters or capture code.
- Camera image enlargement / circular mask NOT included: display image rendering path needs inspection.
- Needs build and on-device validation.

Installation: unzip -o HMB_Persona_Light_V0.3.21_CORE_PATCH.zip "main/*"
Build: idf.py build
