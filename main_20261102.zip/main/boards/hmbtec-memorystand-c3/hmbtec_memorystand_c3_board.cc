/* HMB|TEC MemoryStand C3 V0.4.0
 * XiaoZhi Board – erste Stufe: WiFi und I2S-Audio.
 * OLED, NeoPixel, IR und LD2410 bleiben vorerst inaktiv.
 */
#include "wifi_board.h"
#include "codecs/no_audio_codec.h"
#include "display/display.h"
#include "config.h"

#define TAG "HMBMemoryStandC3"

class HmbtecMemoryStandC3Board : public WifiBoard {
public:
    virtual AudioCodec* GetAudioCodec() override {
        static NoAudioCodecDuplex codec(
            AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_GPIO_BCLK, AUDIO_I2S_GPIO_WS,
            AUDIO_I2S_GPIO_DOUT, AUDIO_I2S_GPIO_DIN);
        return &codec;
    }

    virtual Display* GetDisplay() override {
        static NoDisplay display;
        return &display;
    }
};

DECLARE_BOARD(HmbtecMemoryStandC3Board);
