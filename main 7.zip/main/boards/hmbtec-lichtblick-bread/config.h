#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>

#define AUDIO_INPUT_SAMPLE_RATE  16000
#define AUDIO_OUTPUT_SAMPLE_RATE 24000

#define AUDIO_I2S_METHOD_SIMPLEX
#ifdef AUDIO_I2S_METHOD_SIMPLEX
    #define AUDIO_I2S_MIC_GPIO_WS   GPIO_NUM_4
    #define AUDIO_I2S_MIC_GPIO_SCK  GPIO_NUM_5
    #define AUDIO_I2S_MIC_GPIO_DIN  GPIO_NUM_6
    #define AUDIO_I2S_SPK_GPIO_DOUT GPIO_NUM_7
    #define AUDIO_I2S_SPK_GPIO_BCLK GPIO_NUM_15
    #define AUDIO_I2S_SPK_GPIO_LRCK GPIO_NUM_16
#else
    #define AUDIO_I2S_GPIO_WS GPIO_NUM_4
    #define AUDIO_I2S_GPIO_BCLK GPIO_NUM_5
    #define AUDIO_I2S_GPIO_DIN  GPIO_NUM_6
    #define AUDIO_I2S_GPIO_DOUT GPIO_NUM_7
#endif

#define BUILTIN_LED_GPIO        GPIO_NUM_48
#define BOOT_BUTTON_GPIO        GPIO_NUM_0
#define TOUCH_BUTTON_GPIO       GPIO_NUM_47
#define VOLUME_UP_BUTTON_GPIO   GPIO_NUM_40
#define VOLUME_DOWN_BUTTON_GPIO GPIO_NUM_39

#define DISPLAY_SDA_PIN GPIO_NUM_41
#define DISPLAY_SCL_PIN GPIO_NUM_42
#define DISPLAY_WIDTH   128

#if CONFIG_OLED_SSD1306_128X32
#define DISPLAY_HEIGHT  32
#elif CONFIG_OLED_SSD1306_128X64
#define DISPLAY_HEIGHT  64
#elif CONFIG_OLED_SH1106_128X64
#define DISPLAY_HEIGHT  64
#define SH1106
#else
#error "OLED display type is not selected"
#endif

#define DISPLAY_MIRROR_X true
#define DISPLAY_MIRROR_Y true

// ============================================================================
// HMB | TEC Lichtblick Erweiterungen
// ============================================================================
#define HMBTEC_BUZZER_GPIO       GPIO_NUM_2
#define HMBTEC_BUTTON_GPIO       GPIO_NUM_44   // RX -> Lichtblick-Taster
#define HMBTEC_PIXEL_RING_GPIO   GPIO_NUM_43   // TX -> 12x NeoPixel-Ring
#define HMBTEC_PIXEL_RING_COUNT  12

//--- IR Remote Control
#define HMBTEC_IR_RX_GPIO        GPIO_NUM_18   // TX -> IR receiver 
//--- HEX/BCD-ModeSelect-RotarySwitch
#define HMBTEC_PIO_HEXSW_1       GPIO_NUM_11  
#define HMBTEC_PIO_HEXSW_2       GPIO_NUM_12   

#define HMB_PTT_ONLY_MIC 1  // Mikrofon nur bei aktiver PTT-Nutzung
#define HMB_FLAME_EN 1
#define SINGLE_FLAME_EN 1 // 1 = only flame 1 is used, 0 = all flames are used
#define HMB_FLAME_1 11  // highActive
#define HMB_FLAME_2 12  // highActive
#define HMB_FLAME_3 13  // highActive
#define HMB_FLAME_4 14  // highActive
#define SEELSORGE_EN             0 // 0 = kurz -> Lichtblick lang halten = Chat; 1 = kurz -> Seelsorge, lang -> chat 

//--- HMB|TEC PWA Statistics - first test
#define HMB_PWA_STATS_EN         1
#if HMB_PWA_STATS_EN
    #define HMB_PWA_STATS_URL    "https://mypwa.hmbtec.de/2026/LichtblickStats/api/event.php"
#endif

#endif // _BOARD_CONFIG_H_
