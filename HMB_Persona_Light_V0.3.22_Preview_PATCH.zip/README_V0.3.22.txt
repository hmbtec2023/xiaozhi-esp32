Persona Light V0.3.22: Nur Vorschaugroesse (round display, cover scaling) und Versionskennung.
Basis: funktionierende V0.3.21. Keine Aenderung an SSCMA, KI, MCP oder Zustandsautomat.
Sicherung vor Installation empfohlen.
Installieren im Projektverzeichnis: unzip -o HMB_Persona_Light_V0.3.22_Preview_PATCH.zip "main/*"
Danach: idf.py build
Hinweis: Das physische runde Display schneidet die Bildecken ab. Eine softwareseitige Alpha-Kreis-Maske wird nicht hinzugefuegt.
