HMB|TEC Persona Light V0.3.24
Art-Net Startup-Test nach WLAN-Verbindung: 500ms 512x0, CH1..6 je 350ms 255 (sonst 0), 500ms 512x0, danach MCP-Lichtszene oder kontinuierlich 0.
Broadcast 255.255.255.255 UDP 6454, Universe 1, 20Hz. Test wiederholt sich nach WLAN-Neuverbindung.
Installation: unzip -o <ZIP> "main/*"; idf.py build. Nicht hardwaregetestet.
WICHTIG: Test kann angeschlossene DMX-Leuchten/Motoren kurzzeitig auf volle Leistung setzen.
