HMB|TEC Persona Light V0.3.18 - gezielter Anzeige-Patch

Basis: vom Nutzer hochgeladene V0.3.17-Dateien (sensecap-watcher 5.zip und main 4(1).zip).

Aenderungen:
- sensecap_watcher.cc: kein irrefuehrender FRAME TIMEOUT bei absichtlich pausierter Inferenz.
- application.cc: Status-Texte im State-Change-Handler umbenannt; keine Aenderung an State Machine, Audio, MCP oder Kamera.
- persona_version.h: V0.3.18.

WICHTIG: Anwendungstexte in application.cc gelten fuer diesen Projekt-Build.
Kein Build und kein Hardwaretest in dieser Umgebung moeglich.

Installation: Erst Backup der drei Ziel-Dateien anlegen.
Die ZIP enthaelt Dateien mit den Pfaden relativ zum Projekt-Root.
Entpacken im Projekt-Root mit: unzip -o HMB_Persona_Light_UI_V0.3.18.zip
Vor Build pruefen: grep HMB_PERSONA_VERSION main/boards/sensecap-watcher/persona_version.h
Build: touch main/application.cc main/boards/sensecap-watcher/sensecap_watcher.cc && idf.py build
Firmware pruefen: grep -aob 'V0.3.18' build/xiaozhi.bin
Flash-Port explizit auswaehlen.
