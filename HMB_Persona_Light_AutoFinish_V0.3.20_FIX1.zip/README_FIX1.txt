FIX1: Doppelten Auto-Finish-Block aus LVGL-Timer entfernt. Auto-Finish bleibt in SemanticLightTask. Nicht kompiliert oder auf Hardware getestet.
