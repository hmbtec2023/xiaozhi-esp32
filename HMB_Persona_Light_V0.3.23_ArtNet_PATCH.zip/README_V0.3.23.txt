HMB|TEC Persona Light V0.3.23 – Art-Net Broadcast (auf V0.3.22 aufbauend)

ZIP im Projektroot entpacken: unzip -o HMB_Persona_Light_V0.3.23_ArtNet_PATCH.zip 'main/*'
Danach idf.py build und erst nach erfolgreichem Build flashen.

Art-Net: UDP Port 6454, Broadcast 255.255.255.255, Universe 1 (Port-Address 1), 20 Hz, 512 DMX Slots.
Mapping ab DMX CH1: 1=R, 2=G, 3=B, 4=Brightness, 5=Dynamics (0..100), 6=Transition (100ms/Schritt).
WICHTIG: Dies ist ein generisches Datenmapping, keine fertig konfigurierte RGB-DMX-Leuchtenbelegung.
Die ersten drei Slots enthalten unskalierte RGB-Werte; Brightness ist ein separater Slot.
Empfaenger und Watcher muessen im selben WLAN sein; Broadcast muss durch AP/Netz zugelassen sein.
Sendet kontinuierlich nach der ersten MCP-Lichtszene, bis WLAN-Verbindung getrennt wird.
Es gibt noch kein Art-Net-Blackout bei KI-Fehler oder Disconnect.

V0.3.22 Display-Patch bleibt unveraendert. Bestehende Auto-Finish-/SSCMA-Logik bleibt unveraendert.
Nicht auf der Zielhardware kompiliert oder getestet.
