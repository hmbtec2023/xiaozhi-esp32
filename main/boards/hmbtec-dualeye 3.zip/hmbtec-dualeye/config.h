#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>

// ============================================================================
// Audio
// ============================================================================

#define AUDIO_INPUT_SAMPLE_RATE 16000
#define AUDIO_OUTPUT_SAMPLE_RATE 24000
#define AUDIO_I2S_METHOD_SIMPLEX

#define AUDIO_I2S_MIC_GPIO_WS GPIO_NUM_4
#define AUDIO_I2S_MIC_GPIO_SCK GPIO_NUM_5
#define AUDIO_I2S_MIC_GPIO_DIN GPIO_NUM_6

#define AUDIO_I2S_SPK_GPIO_DOUT GPIO_NUM_7
#define AUDIO_I2S_SPK_GPIO_BCLK GPIO_NUM_15
#define AUDIO_I2S_SPK_GPIO_LRCK GPIO_NUM_16

// ============================================================================
// Board
// ============================================================================
#define HMB_LED_STRIP_GPIO GPIO_NUM_41 // eigentlich SDA, aber hier als GPIO für LED-Streifen genutzt
#define HMB_LED_STRIP_COUNT 6

#define BOOT_BUTTON_GPIO GPIO_NUM_0
#define BUILTIN_LED_GPIO GPIO_NUM_48

// ============================================================================
// HMB | TEC DualEye
// ============================================================================

// 0 = XiaoZhi baseline only
// 1 = DualEye enabled
#define HMB_DUALEYE_ENABLED 1

// 0 = Augen, 1 = zwei synchron spiegelbildliche Flammen
#define HMB_DISPLAY_MODE 1
#define HMB_FLAME_BACK_MIRROR 1
#define HMB_FLAME_AURA_EN 1
#define HMB_FLAME_AURA_STRENGTH 75
#define HMB_FLAME_AURA_RADIUS 40
#define HMB_FLAME_SCALE_PERCENT 125
// Mood Aura: dezente seitliche Farbfelder, unabhaengig von der Flamme.
#define HMB_FLAME_MOOD_EN 1
#define HMB_FLAME_MOOD_DEFAULT_COLOR 0x4080FF
#define HMB_FLAME_MOOD_DEFAULT_INTENSITY 12 // 0..100
#define HMB_FLAME_MOOD_TRANSITION_MS 2000

// Magic Sparkle: seltene Lichtsterne links/rechts im oberen Drittel.
#define HMB_FLAME_SPARKLE_EN 1
#define HMB_FLAME_SPARKLE_MIN_MS 15000
#define HMB_FLAME_SPARKLE_MAX_MS 40000
#define HMB_FLAME_SPARKLE_MAX_ACTIVE 2
#define HMB_FLAME_SPARKLE_INTENSITY 100 // 0..100
#define HMB_FLAME_SPARKLE_STAR_CHANCE 20+80 // Prozent: Kreuz statt Lichtpunkt

// Displaytypen
#define HMB_EYE_GC9D01_160 1
#define HMB_EYE_GC9A01_240 2

// ---------------------------------------------------------------------------
// Aktive Displayvariante
// ---------------------------------------------------------------------------

//--- Kleine Augen:
//#define HMB_EYE_DISPLAY HMB_EYE_GC9D01_160
//--- Große Augen:
#define HMB_EYE_DISPLAY HMB_EYE_GC9A01_240

#if HMB_EYE_DISPLAY == HMB_EYE_GC9D01_160
    #define HMB_EYE_WIDTH 160
    #define HMB_EYE_HEIGHT 160
#elif HMB_EYE_DISPLAY == HMB_EYE_GC9A01_240
    #define HMB_EYE_WIDTH 240
    #define HMB_EYE_HEIGHT 240
#else
    #error "Unsupported HMB DualEye display"
#endif

// ---------------------------------------------------------------------------
// DualEye SPI
// ---------------------------------------------------------------------------

#define HMB_EYE_SCLK GPIO_NUM_11       // grün
#define HMB_EYE_MOSI GPIO_NUM_12       // blau
#define HMB_EYE_DC GPIO_NUM_13         // weiß
#define HMB_EYE_CS_LEFT GPIO_NUM_14    // orange
#define HMB_EYE_CS_RIGHT GPIO_NUM_21   // gelb

// Beide Displays verwenden gemeinsamen Reset
#define HMB_EYE_RST_LEFT GPIO_NUM_43   // TX braun
#define HMB_EYE_RST_RIGHT GPIO_NUM_43  // TX violett

// ============================================================================
// HMB | TEC Lichtblick / Seelsorge
// ============================================================================

#define HMBTEC_BUTTON_GPIO GPIO_NUM_44  // RX -> Lichtblick-Taster

// 0 = Lichtblick One-Shot
// 1 = Seelsorge-Dialog
#define SEELSORGE_EN 1

// ============================================================================
// IR Remote Control - hier nicht verwendet
// ============================================================================

// #define HMBTEC_IR_RX_GPIO GPIO_NUM_18

#endif