#pragma once
// 1: P1/P2/P3 Ansage-Test, Mikrofon gesperrt; 0: normaler Betrieb
#define HMB_ANSAGE_TEST_MODE 1
