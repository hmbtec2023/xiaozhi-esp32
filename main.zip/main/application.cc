#include "application.h"
#include "assets.h"
#include "assets/lang_config.h"
#include "audio_codec.h"
#include "board.h"
#include "cjson_utils.h"
#include "display.h"
#include "mcp_server.h"
#include "mqtt_protocol.h"
#include "settings.h"
#include "system_info.h"
#include "text_glyph_payload.h"
#include "websocket_protocol.h"

#include <driver/gpio.h>
#include <esp_log.h>
#include <arpa/inet.h>
#include <cJSON.h>
#include <cstring>
#include <limits>

#define TAG "Application"

Application::Application() : notify_player_(audio_service_) {
    event_group_ = xEventGroupCreate();

#if CONFIG_USE_DEVICE_AEC && CONFIG_USE_SERVER_AEC
#error "CONFIG_USE_DEVICE_AEC and CONFIG_USE_SERVER_AEC cannot be enabled at the same time"
#elif CONFIG_USE_DEVICE_AEC
    aec_mode_ = kAecOnDeviceSide;
#elif CONFIG_USE_SERVER_AEC
    aec_mode_ = kAecOnServerSide;
#else
    aec_mode_ = kAecOff;
#endif

    esp_timer_create_args_t clock_timer_args = {
        .callback =
            [](void* arg) {
                Application* app = (Application*)arg;
                xEventGroupSetBits(app->event_group_, MAIN_EVENT_CLOCK_TICK);
            },
        .arg = this,
        .dispatch_method = ESP_TIMER_TASK,
        .name = "clock_timer",
        .skip_unhandled_events = true
    };

    esp_timer_create(&clock_timer_args, &clock_timer_handle_);
}

Application::~Application() {
    notify_player_.Stop();

    if (clock_timer_handle_ != nullptr) {
        esp_timer_stop(clock_timer_handle_);
        esp_timer_delete(clock_timer_handle_);
    }

    vEventGroupDelete(event_group_);
}

bool Application::SetDeviceState(DeviceState state) {
    return state_machine_.TransitionTo(state);
}

void Application::Initialize() {
    auto& board = Board::GetInstance();
    SetDeviceState(kDeviceStateStarting);

    // Setup the display
    auto display = board.GetDisplay();
    display->SetupUI();

    // Print board name/version info
    display->SetChatMessage("system", SystemInfo::GetUserAgent().c_str());

    // Setup the audio service
    auto codec = board.GetAudioCodec();
    audio_service_.Initialize(codec);
    audio_service_.Start();

    ESP_LOGI(TAG, "After board/audio init");
    SystemInfo::PrintHeapStats();

    AudioServiceCallbacks callbacks;

    callbacks.on_send_queue_available = [this]() {
        xEventGroupSetBits(event_group_, MAIN_EVENT_SEND_AUDIO);
    };

    callbacks.on_wake_word_detected = [this](const std::string& wake_word) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_WAKE_WORD_DETECTED);
    };

    callbacks.on_vad_change = [this](bool speaking) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_VAD_CHANGE);
    };

    callbacks.on_playback_drained = [this]() {
        xEventGroupSetBits(event_group_, MAIN_EVENT_PLAYBACK_DRAINED);
    };

    callbacks.on_playback_progress = [this](uint32_t playback_id, uint32_t media_position_ms) {
        notify_player_.OnPlaybackProgress(playback_id, media_position_ms);
    };

    audio_service_.SetCallbacks(callbacks);

    // Add state change listeners
    state_machine_.AddStateChangeListener([this](DeviceState old_state, DeviceState new_state) {
        xEventGroupSetBits(event_group_, MAIN_EVENT_STATE_CHANGED);
    });

    // Start the clock timer to update the status bar
    esp_timer_start_periodic(clock_timer_handle_, 1000000);

    // Add MCP common tools
    auto& mcp_server = McpServer::GetInstance();
    mcp_server.AddCommonTools();
    mcp_server.AddUserOnlyTools();

    // Set network event callback
    board.SetNetworkEventCallback([this](NetworkEvent event, const std::string& data) {
        auto display = Board::GetInstance().GetDisplay();

        switch (event) {
            case NetworkEvent::Scanning:
                display->ShowNotification(Lang::Strings::SCANNING_WIFI, 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;

            case NetworkEvent::Connecting: {
                if (data.empty()) {
                    display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                } else {
                    std::string msg = Lang::Strings::CONNECT_TO;
                    msg += data;
                    msg += "...";
                    display->ShowNotification(msg.c_str(), 30000);
                }
                break;
            }

            case NetworkEvent::Connected: {
                std::string msg = Lang::Strings::CONNECTED_TO;
                msg += data;
                display->ShowNotification(msg.c_str(), 30000);
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_CONNECTED);
                break;
            }

            case NetworkEvent::Disconnected:
                xEventGroupSetBits(event_group_, MAIN_EVENT_NETWORK_DISCONNECTED);
                break;

            case NetworkEvent::WifiConfigModeEnter:
                break;

            case NetworkEvent::WifiConfigModeExit:
                break;

            case NetworkEvent::ModemDetecting:
                display->SetStatus(Lang::Strings::DETECTING_MODULE);
                break;

            case NetworkEvent::ModemErrorNoSim:
                Alert(
                    Lang::Strings::ERROR,
                    Lang::Strings::PIN_ERROR,
                    "warning",
                    Lang::Sounds::OGG_ERR_PIN
                );
                break;

            case NetworkEvent::ModemErrorRegDenied:
                Alert(
                    Lang::Strings::ERROR,
                    Lang::Strings::REG_ERROR,
                    "warning",
                    Lang::Sounds::OGG_ERR_REG
                );
                break;

            case NetworkEvent::ModemErrorInitFailed:
                Alert(
                    Lang::Strings::ERROR,
                    Lang::Strings::MODEM_INIT_ERROR,
                    "warning",
                    Lang::Sounds::OGG_EXCLAMATION
                );
                break;

            case NetworkEvent::ModemErrorTimeout:
                display->SetStatus(Lang::Strings::REGISTERING_NETWORK);
                break;
        }
    });

    board.StartNetwork();

    display->UpdateStatusBar(true);
}

void Application::Run() {
    vTaskPrioritySet(nullptr, 10);

    const EventBits_t ALL_EVENTS =
        MAIN_EVENT_SCHEDULE |
        MAIN_EVENT_SEND_AUDIO |
        MAIN_EVENT_WAKE_WORD_DETECTED |
        MAIN_EVENT_VAD_CHANGE |
        MAIN_EVENT_CLOCK_TICK |
        MAIN_EVENT_ERROR |
        MAIN_EVENT_NETWORK_CONNECTED |
        MAIN_EVENT_NETWORK_DISCONNECTED |
        MAIN_EVENT_TOGGLE_CHAT |
        MAIN_EVENT_START_LISTENING |
        MAIN_EVENT_STOP_LISTENING |
        MAIN_EVENT_ACTIVATION_DONE |
        MAIN_EVENT_STATE_CHANGED |
        MAIN_EVENT_PLAYBACK_DRAINED;

    while (true) {
        auto bits = xEventGroupWaitBits(
            event_group_,
            ALL_EVENTS,
            pdTRUE,
            pdFALSE,
            portMAX_DELAY
        );

        if (bits & MAIN_EVENT_ERROR) {
            if (GetDeviceState() == kDeviceStateNotifying) {
                StopNotification();
            }

            SetDeviceState(kDeviceStateIdle);

            Alert(
                Lang::Strings::ERROR,
                last_error_message_.c_str(),
                "cancel",
                Lang::Sounds::OGG_EXCLAMATION
            );
        }

        if (bits & MAIN_EVENT_NETWORK_CONNECTED) {
            HandleNetworkConnectedEvent();
        }

        if (bits & MAIN_EVENT_NETWORK_DISCONNECTED) {
            HandleNetworkDisconnectedEvent();
        }

        if (bits & MAIN_EVENT_ACTIVATION_DONE) {
            HandleActivationDoneEvent();
        }

        if (bits & MAIN_EVENT_STATE_CHANGED) {
            HandleStateChangedEvent();
        }

        if (bits & MAIN_EVENT_PLAYBACK_DRAINED) {
            if (audio_service_.IsPlaybackIdle()) {
                notify_player_.OnPlaybackDrained();
            }

            if (pending_listening_start_ &&
                GetDeviceState() == kDeviceStateListening &&
                audio_service_.IsPlaybackIdle()) {

                pending_listening_start_ = false;
                StartListeningAudio();
            }
        }

        if (bits & MAIN_EVENT_TOGGLE_CHAT) {
            HandleToggleChatEvent();
        }

        if (bits & MAIN_EVENT_START_LISTENING) {
            HandleStartListeningEvent();
        }

        if (bits & MAIN_EVENT_STOP_LISTENING) {
            HandleStopListeningEvent();
        }

        if (bits & MAIN_EVENT_SEND_AUDIO) {
            while (auto packet = audio_service_.PopPacketFromSendQueue()) {
                if (protocol_ && !protocol_->SendAudio(std::move(packet))) {
                    while (audio_service_.PopPacketFromSendQueue())
                        ;
                    break;
                }
            }
        }

        if (bits & MAIN_EVENT_WAKE_WORD_DETECTED) {
            HandleWakeWordDetectedEvent();
        }

        if (bits & MAIN_EVENT_VAD_CHANGE) {
            if (GetDeviceState() == kDeviceStateListening) {
                auto led = Board::GetInstance().GetLed();
                led->OnStateChanged();
            }
        }

        if (bits & MAIN_EVENT_SCHEDULE) {
            std::unique_lock<std::mutex> lock(mutex_);
            auto tasks = std::move(main_tasks_);
            lock.unlock();

            for (auto& task : tasks) {
                task();
            }
        }

        if (bits & MAIN_EVENT_CLOCK_TICK) {
            clock_ticks_++;

            auto display = Board::GetInstance().GetDisplay();
            display->UpdateStatusBar();

            if (clock_ticks_ % 10 == 0) {
                SystemInfo::PrintHeapStats();
            }
        }
    }
}

void Application::HandleNetworkConnectedEvent() {
    ESP_LOGI(TAG, "Network connected");

    auto state = GetDeviceState();

    if (state == kDeviceStateStarting || state == kDeviceStateWifiConfiguring) {
        SetDeviceState(kDeviceStateActivating);

        if (activation_task_handle_ != nullptr) {
            ESP_LOGW(TAG, "Activation task already running");
            return;
        }

        xTaskCreate(
            [](void* arg) {
                Application* app = static_cast<Application*>(arg);
                app->ActivationTask();
                app->activation_task_handle_ = nullptr;
                vTaskDelete(NULL);
            },
            "activation",
            4096 * 2,
            this,
            2,
            &activation_task_handle_
        );
    }

    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleNetworkDisconnectedEvent() {
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
    }

    if (state == kDeviceStateConnecting ||
        state == kDeviceStateListening ||
        state == kDeviceStateSpeaking) {

        ESP_LOGI(TAG, "Closing audio channel due to network disconnection");
        protocol_->CloseAudioChannel();
    }

    auto display = Board::GetInstance().GetDisplay();
    display->UpdateStatusBar(true);
}

void Application::HandleActivationDoneEvent() {
    ESP_LOGI(TAG, "Activation done");

    SystemInfo::PrintHeapStats();
    SetDeviceState(kDeviceStateIdle);

    has_server_time_ = ota_->HasServerTime();

    const bool has_error = !last_error_message_.empty();

    if (!has_error) {
        auto display = Board::GetInstance().GetDisplay();

        std::string message =
            std::string(Lang::Strings::VERSION) +
            ota_->GetCurrentVersion();

        display->ShowNotification(message.c_str());
        display->SetChatMessage("system", "");
    }

    ota_.reset();

    auto& board = Board::GetInstance();
    board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);

    if (!has_error) {
        Schedule([this]() {
            audio_service_.PlaySound(Lang::Sounds::OGG_SUCCESS);
        });
    }
}

void Application::ActivationTask() {
    ota_ = std::make_unique<Ota>();

    CheckAssetsVersion();
    CheckNewVersion();
    InitializeProtocol();

    xEventGroupSetBits(event_group_, MAIN_EVENT_ACTIVATION_DONE);
}

void Application::CheckAssetsVersion() {
    if (assets_version_checked_) {
        return;
    }

    assets_version_checked_ = true;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto& assets = Assets::GetInstance();

    if (!assets.partition_valid()) {
        ESP_LOGW(TAG, "Assets partition is disabled for board %s", BOARD_NAME);
        return;
    }

    Settings settings("assets", true);

    std::string download_url = settings.GetString("download_url");

    if (!download_url.empty()) {
        settings.EraseKey("download_url");

        char message[256];

        snprintf(
            message,
            sizeof(message),
            Lang::Strings::FOUND_NEW_ASSETS,
            download_url.c_str()
        );

        Alert(
            Lang::Strings::LOADING_ASSETS,
            message,
            "cloud_download",
            Lang::Sounds::OGG_UPGRADE
        );

        vTaskDelay(pdMS_TO_TICKS(3000));

        SetDeviceState(kDeviceStateUpgrading);
        board.SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);

        display->SetChatMessage(
            "system",
            Lang::Strings::PLEASE_WAIT
        );

        bool success =
            assets.Download(
                download_url,
                [this, display](int progress, size_t speed) -> void {
                    char buffer[32];

                    snprintf(
                        buffer,
                        sizeof(buffer),
                        "%d%% %uKB/s",
                        progress,
                        speed / 1024
                    );

                    Schedule([display, message = std::string(buffer)]() {
                        display->SetChatMessage(
                            "system",
                            message.c_str()
                        );
                    });
                }
            );

        board.SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);

        vTaskDelay(pdMS_TO_TICKS(1000));

        if (!success) {
            Alert(
                Lang::Strings::ERROR,
                Lang::Strings::DOWNLOAD_ASSETS_FAILED,
                "cancel",
                Lang::Sounds::OGG_EXCLAMATION
            );

            vTaskDelay(pdMS_TO_TICKS(2000));

            SetDeviceState(kDeviceStateActivating);
            return;
        }
    }

    assets.Apply();

    display->SetChatMessage("system", "");
    display->SetEmotion("robot_2");
}

void Application::CheckNewVersion() {
    const int MAX_RETRY = 10;

    int retry_count = 0;
    int retry_delay = 10;

    auto& board = Board::GetInstance();

    while (true) {
        auto display = board.GetDisplay();

        display->SetStatus(
            Lang::Strings::CHECKING_NEW_VERSION
        );

        auto check = ota_->CheckVersion();

        if (!check) {
            retry_count++;

            if (retry_count >= MAX_RETRY) {
                ESP_LOGE(TAG, "Too many retries, exit version check");
                return;
            }

            const auto& err = check.error();

            char error_message[160];

            int error_message_length =
                snprintf(
                    error_message,
                    sizeof(error_message),
                    "%s",
                    err.ToString().c_str()
                );

            if (error_message_length < 0 ||
                error_message_length >= static_cast<int>(sizeof(error_message))) {

                snprintf(
                    error_message,
                    sizeof(error_message),
                    "%s",
                    err.Message()
                );
            }

            char buffer[320];

            int alert_message_length =
                snprintf(
                    buffer,
                    sizeof(buffer),
                    Lang::Strings::CHECK_NEW_VERSION_FAILED,
                    retry_delay,
                    error_message
                );

            if (alert_message_length < 0 ||
                alert_message_length >= static_cast<int>(sizeof(buffer))) {

                snprintf(
                    buffer,
                    sizeof(buffer),
                    "%s",
                    err.Message()
                );
            }

            Alert(
                Lang::Strings::ERROR,
                buffer,
                "cloud_off",
                Lang::Sounds::OGG_EXCLAMATION
            );

            ESP_LOGW(
                TAG,
                "Check new version failed, retry in %d seconds (%d/%d)",
                retry_delay,
                retry_count,
                MAX_RETRY
            );

            for (int i = 0; i < retry_delay; i++) {
                vTaskDelay(pdMS_TO_TICKS(1000));

                if (GetDeviceState() == kDeviceStateIdle) {
                    break;
                }
            }

            retry_delay *= 2;
            continue;
        }

        retry_count = 0;
        retry_delay = 10;

        if (ota_->HasNewVersion()) {
            if (UpgradeFirmware(
                    ota_->GetFirmwareUrl(),
                    ota_->GetFirmwareVersion())) {
                return;
            }
        }

        ota_->MarkCurrentVersionValid();

        if (!ota_->HasActivationCode() &&
            !ota_->HasActivationChallenge()) {
            break;
        }

        display->SetStatus(Lang::Strings::ACTIVATION);

        if (ota_->HasActivationCode()) {
            ShowActivationCode(
                ota_->GetActivationCode(),
                ota_->GetActivationMessage()
            );
        }

        for (int i = 0; i < 10; ++i) {
            ESP_LOGI(
                TAG,
                "Activating... %d/%d",
                i + 1,
                10
            );

            esp_err_t err = ota_->Activate();

            if (err == ESP_OK) {
                break;
            } else if (err == ESP_ERR_TIMEOUT) {
                vTaskDelay(pdMS_TO_TICKS(3000));
            } else {
                vTaskDelay(pdMS_TO_TICKS(10000));
            }

            if (GetDeviceState() == kDeviceStateIdle) {
                break;
            }
        }
    }
}

void Application::InitializeProtocol() {
    auto& board = Board::GetInstance();

    auto display = board.GetDisplay();
    auto codec = board.GetAudioCodec();

    display->SetStatus(
        Lang::Strings::LOADING_PROTOCOL
    );

    if (ota_->HasMqttConfig()) {
        protocol_ = std::make_unique<MqttProtocol>();
    } else if (ota_->HasWebsocketConfig()) {
        protocol_ = std::make_unique<WebsocketProtocol>();
    } else {
        ESP_LOGW(
            TAG,
            "No protocol specified in the OTA config, using MQTT"
        );

        protocol_ = std::make_unique<MqttProtocol>();
    }

    protocol_->OnConnected([this]() {
        DismissAlert();
    });

    protocol_->OnNetworkError(
        [this](const std::string& message) {
            last_error_message_ = message;

            xEventGroupSetBits(
                event_group_,
                MAIN_EVENT_ERROR
            );
        }
    );

    protocol_->OnIncomingAudio(
        [this](std::unique_ptr<AudioStreamPacket> packet) {
            if (GetDeviceState() == kDeviceStateSpeaking) {
                audio_service_.PushPacketToDecodeQueue(
                    std::move(packet)
                );
            }
        }
    );

    protocol_->OnAudioChannelOpened(
        [this, codec, &board]() {
            board.SetPowerSaveLevel(
                PowerSaveLevel::PERFORMANCE
            );

            if (protocol_->server_sample_rate() !=
                codec->output_sample_rate()) {

                ESP_LOGW(
                    TAG,
                    "Server sample rate %d does not match device output sample rate %d, "
                    "resampling may cause distortion",
                    protocol_->server_sample_rate(),
                    codec->output_sample_rate()
                );
            }
        }
    );

    protocol_->OnAudioChannelClosed(
        [this, &board]() {
            board.SetPowerSaveLevel(
                PowerSaveLevel::LOW_POWER
            );

            Schedule([this]() {
                auto display =
                    Board::GetInstance().GetDisplay();

                display->SetChatMessage(
                    "system",
                    ""
                );

                SetDeviceState(
                    kDeviceStateIdle
                );
            });
        }
    );

    protocol_->OnIncomingJson(
        [this, display](const cJSON* root) {

            auto type =
                cJSON_GetObjectItem(
                    root,
                    "type"
                );

            if (!cJSON_IsString(type)) {
                ESP_LOGW(
                    TAG,
                    "Incoming JSON message has no type"
                );
                return;
            }

            if (strcmp(
                    type->valuestring,
                    "notify") == 0) {

                auto audio_url =
                    cJSON_GetObjectItem(
                        root,
                        "audio_url"
                    );

                if (!cJSON_IsString(audio_url) ||
                    audio_url->valuestring[0] == '\0') {

                    ESP_LOGW(
                        TAG,
                        "Notify message requires audio_url"
                    );
                    return;
                }

                std::vector<NotifySubtitle> subtitles;

                auto subtitles_json =
                    cJSON_GetObjectItem(
                        root,
                        "subtitles"
                    );

                if (subtitles_json != nullptr &&
                    !cJSON_IsArray(subtitles_json)) {

                    ESP_LOGW(
                        TAG,
                        "Notify subtitles must be an array"
                    );
                    return;
                }

                if (cJSON_IsArray(subtitles_json)) {
                    cJSON* item = nullptr;

                    cJSON_ArrayForEach(item, subtitles_json) {
                        auto start_ms =
                            cJSON_GetObjectItem(
                                item,
                                "start_ms"
                            );

                        auto text =
                            cJSON_GetObjectItem(
                                item,
                                "text"
                            );

                        if (!cJSON_IsNumber(start_ms) ||
                            start_ms->valuedouble < 0 ||
                            start_ms->valuedouble >
                                std::numeric_limits<uint32_t>::max() ||
                            !cJSON_IsString(text)) {

                            ESP_LOGW(
                                TAG,
                                "Ignoring invalid notify subtitle"
                            );

                            continue;
                        }

                        subtitles.push_back({
                            .start_ms =
                                static_cast<uint32_t>(
                                    start_ms->valuedouble
                                ),
                            .text =
                                text->valuestring
                        });
                    }
                }

                Schedule(
                    [this,
                     url = std::string(audio_url->valuestring),
                     subtitles = std::move(subtitles)]() mutable {

                        StartNotification(
                            std::move(url),
                            std::move(subtitles)
                        );
                    }
                );

            } else if (strcmp(
                           type->valuestring,
                           "tts") == 0) {

                auto state =
                    cJSON_GetObjectItem(
                        root,
                        "state"
                    );

                if (!cJSON_IsString(state)) {
                    return;
                }

                if (strcmp(
                        state->valuestring,
                        "start") == 0) {

                    Schedule([this]() {
                        aborted_ = false;

                        SetDeviceState(
                            kDeviceStateSpeaking
                        );
                    });

                } else if (strcmp(
                               state->valuestring,
                               "stop") == 0) {

                    Schedule([this]() {
                        if (GetDeviceState() ==
                            kDeviceStateSpeaking) {

                            if (listening_mode_ ==
                                kListeningModeManualStop) {

                                ESP_LOGI(
                                    TAG,
                                    "TTS finished in manual-stop mode -> standby"
                                );

                                SetDeviceState(
                                    kDeviceStateIdle
                                );

                                if (one_shot_invocation_active_) {
                                    ESP_LOGI(
                                        TAG,
                                        "One-shot invocation finished"
                                    );

                                    one_shot_invocation_active_ = false;

                                    if (one_shot_finished_callback_) {
                                        one_shot_finished_callback_();
                                    }
                                }

                            } else {
                                SetDeviceState(
                                    kDeviceStateListening
                                );
                            }
                        }
                    });

                } else if (strcmp(
                               state->valuestring,
                               "sentence_start") == 0) {

                    auto text =
                        cJSON_GetObjectItem(
                            root,
                            "text"
                        );

                    if (cJSON_IsString(text)) {
                        std::vector<TextGlyph> glyphs;
                        uint8_t bpp = 0;

                        if (!TextGlyphPayload::Parse(
                                root,
                                glyphs,
                                bpp)) {

                            glyphs.clear();
                        }

                        ESP_LOGI(
                            TAG,
                            "<< %s",
                            text->valuestring
                        );

                        Schedule(
                            [display,
                             message =
                                 std::string(
                                     text->valuestring
                                 ),
                             glyphs =
                                 std::move(glyphs),
                             bpp]() {

                                display->AddTextGlyphs(
                                    glyphs,
                                    bpp
                                );

                                display->SetChatMessage(
                                    "assistant",
                                    message.c_str()
                                );
                            }
                        );
                    }
                }

            } else if (strcmp(
                           type->valuestring,
                           "stt") == 0) {

                auto text =
                    cJSON_GetObjectItem(
                        root,
                        "text"
                    );

                if (cJSON_IsString(text)) {
                    std::vector<TextGlyph> glyphs;
                    uint8_t bpp = 0;

                    if (!TextGlyphPayload::Parse(
                            root,
                            glyphs,
                            bpp)) {

                        glyphs.clear();
                    }

                    ESP_LOGI(
                        TAG,
                        ">> %s",
                        text->valuestring
                    );

                    Schedule(
                        [display,
                         message =
                             std::string(
                                 text->valuestring
                             ),
                         glyphs =
                             std::move(glyphs),
                         bpp]() {

                            display->AddTextGlyphs(
                                glyphs,
                                bpp
                            );

                            display->SetChatMessage(
                                "user",
                                message.c_str()
                            );
                        }
                    );
                }

            } else if (strcmp(
                           type->valuestring,
                           "llm") == 0) {

                auto emotion =
                    cJSON_GetObjectItem(
                        root,
                        "emotion"
                    );

                if (cJSON_IsString(emotion)) {
                    Schedule(
                        [display,
                         emotion_str =
                             std::string(
                                 emotion->valuestring
                             )]() {

                            display->SetEmotion(
                                emotion_str.c_str()
                            );
                        }
                    );
                }

            } else if (strcmp(
                           type->valuestring,
                           "mcp") == 0) {

                auto payload =
                    cJSON_GetObjectItem(
                        root,
                        "payload"
                    );

                if (cJSON_IsObject(payload)) {
                    McpServer::GetInstance()
                        .ParseMessage(payload);
                }

            } else if (strcmp(
                           type->valuestring,
                           "system") == 0) {

                auto command =
                    cJSON_GetObjectItem(
                        root,
                        "command"
                    );

                if (cJSON_IsString(command)) {
                    ESP_LOGI(
                        TAG,
                        "System command: %s",
                        command->valuestring
                    );

                    if (strcmp(
                            command->valuestring,
                            "reboot") == 0) {

                        Schedule([this]() {
                            Reboot();
                        });

                    } else {
                        ESP_LOGW(
                            TAG,
                            "Unknown system command: %s",
                            command->valuestring
                        );
                    }
                }

            } else if (strcmp(
                           type->valuestring,
                           "alert") == 0) {

                auto status =
                    cJSON_GetObjectItem(
                        root,
                        "status"
                    );

                auto message =
                    cJSON_GetObjectItem(
                        root,
                        "message"
                    );

                auto emotion =
                    cJSON_GetObjectItem(
                        root,
                        "emotion"
                    );

                if (cJSON_IsString(status) &&
                    cJSON_IsString(message) &&
                    cJSON_IsString(emotion)) {

                    Alert(
                        status->valuestring,
                        message->valuestring,
                        emotion->valuestring,
                        Lang::Sounds::OGG_VIBRATION
                    );

                } else {
                    ESP_LOGW(
                        TAG,
                        "Alert command requires status, message and emotion"
                    );
                }

#if CONFIG_RECEIVE_CUSTOM_MESSAGE

            } else if (strcmp(
                           type->valuestring,
                           "custom") == 0) {

                auto payload =
                    cJSON_GetObjectItem(
                        root,
                        "payload"
                    );

                CJsonStringUniquePtr root_json(
                    cJSON_PrintUnformatted(root)
                );

                ESP_LOGI(
                    TAG,
                    "Received custom message: %s",
                    root_json ? root_json.get() : ""
                );

                if (cJSON_IsObject(payload)) {
                    CJsonStringUniquePtr payload_json(
                        cJSON_PrintUnformatted(payload)
                    );

                    if (payload_json) {
                        Schedule(
                            [this,
                             display,
                             payload_str =
                                 std::string(
                                     payload_json.get()
                                 )]() {

                                display->SetChatMessage(
                                    "system",
                                    payload_str.c_str()
                                );
                            }
                        );
                    }

                } else {
                    ESP_LOGW(
                        TAG,
                        "Invalid custom message format: missing payload"
                    );
                }
#endif

            } else {
                ESP_LOGW(
                    TAG,
                    "Unknown message type: %s",
                    type->valuestring
                );
            }
        }
    );

    protocol_->Start();
}

void Application::ShowActivationCode(
    const std::string& code,
    const std::string& message) {

    struct digit_sound {
        char digit;
        const std::string_view& sound;
    };

    static const std::array<digit_sound, 10> digit_sounds{
        {
            digit_sound{'0', Lang::Sounds::OGG_0},
            digit_sound{'1', Lang::Sounds::OGG_1},
            digit_sound{'2', Lang::Sounds::OGG_2},
            digit_sound{'3', Lang::Sounds::OGG_3},
            digit_sound{'4', Lang::Sounds::OGG_4},
            digit_sound{'5', Lang::Sounds::OGG_5},
            digit_sound{'6', Lang::Sounds::OGG_6},
            digit_sound{'7', Lang::Sounds::OGG_7},
            digit_sound{'8', Lang::Sounds::OGG_8},
            digit_sound{'9', Lang::Sounds::OGG_9}
        }
    };

    Alert(
        Lang::Strings::ACTIVATION,
        message.c_str(),
        "link",
        Lang::Sounds::OGG_ACTIVATION
    );

    for (const auto& digit : code) {
        auto it =
            std::find_if(
                digit_sounds.begin(),
                digit_sounds.end(),
                [digit](const digit_sound& ds) {
                    return ds.digit == digit;
                }
            );

        if (it != digit_sounds.end()) {
            audio_service_.PlaySound(
                it->sound
            );
        }
    }
}

void Application::Alert(
    const char* status,
    const char* message,
    const char* emotion,
    const std::string_view& sound) {

    ESP_LOGW(
        TAG,
        "Alert [%s] %s: %s",
        emotion,
        status,
        message
    );

    auto display =
        Board::GetInstance().GetDisplay();

    display->SetStatus(status);
    display->SetEmotion(emotion);
    display->SetChatMessage(
        "system",
        message
    );

    if (!sound.empty()) {
        audio_service_.PlaySound(sound);
    }
}

void Application::DismissAlert() {
    last_error_message_.clear();

    if (GetDeviceState() ==
        kDeviceStateIdle) {

        auto display =
            Board::GetInstance().GetDisplay();

        display->SetStatus(
            Lang::Strings::STANDBY
        );

        display->SetEmotion("neutral");
        display->SetChatMessage(
            "system",
            ""
        );
    }
}

void Application::ToggleChatState() {
    xEventGroupSetBits(
        event_group_,
        MAIN_EVENT_TOGGLE_CHAT
    );
}

void Application::StartListening() {
    xEventGroupSetBits(
        event_group_,
        MAIN_EVENT_START_LISTENING
    );
}

void Application::StopListening() {
    xEventGroupSetBits(
        event_group_,
        MAIN_EVENT_STOP_LISTENING
    );
}

void Application::HandleToggleChatEvent() {
    auto state = GetDeviceState();

    if (state == kDeviceStateNotifying) {
        StopNotification();
        state = kDeviceStateIdle;
    }

    if (state == kDeviceStateActivating) {
        SetDeviceState(kDeviceStateIdle);
        return;

    } else if (state ==
               kDeviceStateWifiConfiguring) {

        audio_service_.EnableAudioTesting(true);

        SetDeviceState(
            kDeviceStateAudioTesting
        );

        return;

    } else if (state ==
               kDeviceStateAudioTesting) {

        audio_service_.EnableAudioTesting(false);

        SetDeviceState(
            kDeviceStateWifiConfiguring
        );

        return;
    }

    if (!protocol_) {
        ESP_LOGE(
            TAG,
            "Protocol not initialized"
        );
        return;
    }

    if (state == kDeviceStateIdle) {
        ListeningMode mode =
            GetDefaultListeningMode();

        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(
                kDeviceStateConnecting
            );

            Schedule([this, mode]() {
                ContinueOpenAudioChannel(mode);
            });

            return;
        }

        SetListeningMode(mode);

    } else if (state ==
               kDeviceStateSpeaking) {

        AbortSpeaking(
            kAbortReasonNone
        );

    } else if (state ==
               kDeviceStateListening) {

        protocol_->CloseAudioChannel();
    }
}

void Application::ContinueOpenAudioChannel(
    ListeningMode mode) {

    if (GetDeviceState() !=
        kDeviceStateConnecting) {
        return;
    }

    auto& board =
        Board::GetInstance();

    board.SetPowerSaveLevel(
        PowerSaveLevel::PERFORMANCE
    );

    if (!protocol_->IsAudioChannelOpened()) {
        if (!protocol_->OpenAudioChannel()) {
            SetDeviceState(
                kDeviceStateIdle
            );
            return;
        }
    }

    SetListeningMode(mode);
}

void Application::HandleStartListeningEvent() {
    auto state = GetDeviceState();

    if (state ==
        kDeviceStateNotifying) {

        StopNotification();
        state = kDeviceStateIdle;
    }

    if (state ==
        kDeviceStateActivating) {

        SetDeviceState(
            kDeviceStateIdle
        );

        return;

    } else if (state ==
               kDeviceStateWifiConfiguring) {

        audio_service_.EnableAudioTesting(true);

        SetDeviceState(
            kDeviceStateAudioTesting
        );

        return;
    }

    if (!protocol_) {
        ESP_LOGE(
            TAG,
            "Protocol not initialized"
        );

        return;
    }

    if (state ==
        kDeviceStateIdle) {

        if (!protocol_->IsAudioChannelOpened()) {
            SetDeviceState(
                kDeviceStateConnecting
            );

            Schedule([this]() {
                ContinueOpenAudioChannel(
                    kListeningModeManualStop
                );
            });

            return;
        }

        SetListeningMode(
            kListeningModeManualStop
        );

    } else if (state ==
               kDeviceStateSpeaking) {

        AbortSpeaking(
            kAbortReasonNone
        );

        SetListeningMode(
            kListeningModeManualStop
        );
    }
}

void Application::HandleStopListeningEvent() {
    auto state = GetDeviceState();

    if (state ==
        kDeviceStateNotifying) {

        StopNotification();

    } else if (state ==
               kDeviceStateAudioTesting) {

        audio_service_.EnableAudioTesting(false);

        SetDeviceState(
            kDeviceStateWifiConfiguring
        );

        return;

    } else if (state ==
               kDeviceStateListening) {

        if (protocol_) {
            protocol_->SendStopListening();
        }

        SetDeviceState(
            kDeviceStateIdle
        );
    }
}

void Application::HandleWakeWordDetectedEvent() {
    if (!protocol_) {
        return;
    }

    auto state =
        GetDeviceState();

    auto wake_word =
        audio_service_.GetLastWakeWord();

    ESP_LOGI(
        TAG,
        "Wake word detected: %s (state: %d)",
        wake_word.c_str(),
        (int)state
    );

    if (state ==
        kDeviceStateIdle) {

        BeginWakeWordInvoke(
            wake_word
        );

    } else if (state ==
               kDeviceStateNotifying) {

        StopNotification();

        BeginWakeWordInvoke(
            wake_word
        );

    } else if (state ==
                   kDeviceStateSpeaking ||
               state ==
                   kDeviceStateListening) {

        AbortSpeaking(
            kAbortReasonWakeWordDetected
        );

        while (
            audio_service_
                .PopPacketFromSendQueue())
            ;

        if (state ==
            kDeviceStateListening) {

            protocol_->SendStartListening(
                GetDefaultListeningMode()
            );

            audio_service_.ResetDecoder();

            audio_service_.PlaySound(
                Lang::Sounds::OGG_POPUP
            );

            audio_service_
                .EnableWakeWordDetection(true);

        } else {
            play_popup_on_listening_ = true;

            SetListeningMode(
                GetDefaultListeningMode()
            );
        }

    } else if (state ==
               kDeviceStateActivating) {

        SetDeviceState(
            kDeviceStateIdle
        );
    }
}

/*
 * Start a wake-word invocation.
 *
 * manual_stop = false:
 *     normal XiaoZhi behaviour.
 *     After the answer the device can return to listening.
 *
 * manual_stop = true:
 *     one-shot behaviour for the Lichtblick button.
 *     After the answer the device returns to idle/standby.
 */
void Application::BeginWakeWordInvoke(
    const std::string& wake_word,
    bool manual_stop) {

    audio_service_.EncodeWakeWord();

    if (!SetDeviceState(
            kDeviceStateConnecting)) {

        audio_service_
            .EnableWakeWordDetection(true);

        return;
    }

    if (!protocol_->IsAudioChannelOpened()) {
        Schedule(
            [this,
             wake_word,
             manual_stop]() {

                ContinueWakeWordInvoke(
                    wake_word,
                    manual_stop
                );
            }
        );

        return;
    }

    ContinueWakeWordInvoke(
        wake_word,
        manual_stop
    );
}

void Application::ContinueWakeWordInvoke(
    const std::string& wake_word,
    bool manual_stop) {

    if (GetDeviceState() !=
        kDeviceStateConnecting) {
        return;
    }

    auto& board =
        Board::GetInstance();

    board.SetPowerSaveLevel(
        PowerSaveLevel::PERFORMANCE
    );

    if (!protocol_->IsAudioChannelOpened()) {
        if (!protocol_->OpenAudioChannel()) {
            SetDeviceState(
                kDeviceStateIdle
            );

            return;
        }
    }

    ESP_LOGI(
        TAG,
        "Wake word detected: %s, manual_stop=%s",
        wake_word.c_str(),
        manual_stop ? "true" : "false"
    );

#if CONFIG_SEND_WAKE_WORD_DATA

    while (
        auto packet =
            audio_service_
                .PopWakeWordPacket()) {

        protocol_->SendAudio(
            std::move(packet)
        );
    }

    protocol_->SendWakeWordDetected(
        wake_word
    );

    SetListeningMode(
        manual_stop
            ? kListeningModeManualStop
            : GetDefaultListeningMode()
    );

#else

    play_popup_on_listening_ = true;

    SetListeningMode(
        manual_stop
            ? kListeningModeManualStop
            : GetDefaultListeningMode()
    );

#endif
}

void Application::HandleStateChangedEvent() {
    DeviceState new_state =
        state_machine_.GetState();

    clock_ticks_ = 0;

    pending_listening_start_ = false;

    auto& board =
        Board::GetInstance();

    auto display =
        board.GetDisplay();

    auto led =
        board.GetLed();

    led->OnStateChanged();

    switch (new_state) {
        case kDeviceStateUnknown:

        case kDeviceStateIdle:
            if (last_error_message_.empty()) {
                display->SetStatus(
                    Lang::Strings::STANDBY
                );

                display->ClearChatMessages();

                display->SetEmotion(
                    "neutral"
                );
            }

            audio_service_
                .EnableVoiceProcessing(false);

            audio_service_
                .EnableWakeWordDetection(true);

            break;

        case kDeviceStateConnecting:
            display->SetStatus(
                Lang::Strings::CONNECTING
            );

            display->SetEmotion(
                "neutral"
            );

            display->SetChatMessage(
                "system",
                ""
            );

            break;

        case kDeviceStateListening:
            display->SetStatus(
                Lang::Strings::LISTENING
            );

            display->SetEmotion(
                "neutral"
            );

            if (play_popup_on_listening_ ||
                !audio_service_
                     .IsAudioProcessorRunning()) {

                if (listening_mode_ ==
                        kListeningModeAutoStop &&
                    !audio_service_
                         .IsPlaybackIdle()) {

                    pending_listening_start_ =
                        true;

                } else {
                    StartListeningAudio();
                }

            } else {
                ConfigureWakeWordForListening();
            }

            break;

        case kDeviceStateSpeaking:
            display->SetStatus(
                Lang::Strings::SPEAKING
            );

            if (listening_mode_ !=
                kListeningModeRealtime) {

                audio_service_
                    .EnableVoiceProcessing(false);

                audio_service_
                    .EnableWakeWordDetection(
                        audio_service_
                            .IsAfeWakeWord()
                    );
            }

            audio_service_.ResetDecoder();

            break;

        case kDeviceStateNotifying:
            display->SetStatus(
                Lang::Strings::SPEAKING
            );

            audio_service_
                .EnableVoiceProcessing(false);

            audio_service_
                .EnableWakeWordDetection(
                    audio_service_
                        .IsAfeWakeWord()
                );

            break;

        case kDeviceStateWifiConfiguring:
            audio_service_
                .EnableVoiceProcessing(false);

            audio_service_
                .EnableWakeWordDetection(false);

            break;

        default:
            break;
    }
}

void Application::StartListeningAudio() {
    if (GetDeviceState() !=
        kDeviceStateListening) {
        return;
    }

    protocol_->SendStartListening(
        listening_mode_
    );

    audio_service_
        .EnableVoiceProcessing(true);

    ConfigureWakeWordForListening();

    if (play_popup_on_listening_) {
        play_popup_on_listening_ = false;

        audio_service_.PlaySound(
            Lang::Sounds::OGG_POPUP
        );
    }
}

void Application::ConfigureWakeWordForListening() {
#ifdef CONFIG_WAKE_WORD_DETECTION_IN_LISTENING

    audio_service_.EnableWakeWordDetection(
        audio_service_.IsAfeWakeWord()
    );

#else

    audio_service_
        .EnableWakeWordDetection(false);

#endif
}

void Application::StartNotification(
    std::string audio_url,
    std::vector<NotifySubtitle> subtitles) {

    if (GetDeviceState() !=
            kDeviceStateIdle ||
        notify_player_.IsBusy()) {

        ESP_LOGW(
            TAG,
            "Ignoring notify message while device is busy"
        );

        return;
    }

    auto& board =
        Board::GetInstance();

    board.SetPowerSaveLevel(
        PowerSaveLevel::PERFORMANCE
    );

    audio_service_
        .EnableVoiceProcessing(false);

    audio_service_
        .EnableWakeWordDetection(
            audio_service_.IsAfeWakeWord()
        );

    audio_service_
        .ReleaseWakeWordResources();

    while (
        audio_service_
            .PopPacketFromSendQueue()) {
    }

    if (!SetDeviceState(
            kDeviceStateNotifying)) {

        board.SetPowerSaveLevel(
            PowerSaveLevel::LOW_POWER
        );

        return;
    }

    audio_service_.ResetDecoder();

    uint32_t playback_id =
        ++notification_playback_id_;

    if (playback_id == 0) {
        playback_id =
            ++notification_playback_id_;
    }

    audio_service_.PlaySound(
        Lang::Sounds::OGG_POPUP
    );

    bool started =
        notify_player_.Start(
            std::move(audio_url),
            std::move(subtitles),
            playback_id,

            [this](
                uint32_t id,
                const std::string& text) {

                Schedule(
                    [this, id, text]() {
                        if (GetDeviceState() ==
                                kDeviceStateNotifying &&
                            notification_playback_id_ ==
                                id) {

                            Board::GetInstance()
                                .GetDisplay()
                                ->SetChatMessage(
                                    "assistant",
                                    text.c_str()
                                );
                        }
                    }
                );
            },

            [this](
                uint32_t id,
                bool success) {

                Schedule(
                    [this, id, success]() {
                        HandleNotificationFinished(
                            id,
                            success
                        );
                    }
                );
            }
        );

    if (!started) {
        ESP_LOGE(
            TAG,
            "Failed to start notification playback"
        );

        StopNotification();
    }
}

void Application::StopNotification() {
    notify_player_.Stop();

    audio_service_.ResetDecoder();

    auto& board =
        Board::GetInstance();

    board.GetDisplay()
        ->SetChatMessage(
            "assistant",
            ""
        );

    board.SetPowerSaveLevel(
        PowerSaveLevel::LOW_POWER
    );

    if (GetDeviceState() ==
        kDeviceStateNotifying) {

        SetDeviceState(
            kDeviceStateIdle
        );
    }
}

void Application::HandleNotificationFinished(
    uint32_t playback_id,
    bool success) {

    if (GetDeviceState() !=
            kDeviceStateNotifying ||
        notification_playback_id_ !=
            playback_id) {

        return;
    }

    ESP_LOGI(
        TAG,
        "Notification playback %lu %s",
        static_cast<unsigned long>(
            playback_id
        ),
        success
            ? "completed"
            : "failed"
    );

    StopNotification();
}

void Application::Schedule(
    std::function<void()>&& callback) {

    {
        std::lock_guard<std::mutex> lock(
            mutex_
        );

        main_tasks_.push_back(
            std::move(callback)
        );
    }

    xEventGroupSetBits(
        event_group_,
        MAIN_EVENT_SCHEDULE
    );
}

void Application::AbortSpeaking(
    AbortReason reason) {

    ESP_LOGI(
        TAG,
        "Abort speaking"
    );

    aborted_ = true;

    if (protocol_) {
        protocol_->SendAbortSpeaking(
            reason
        );
    }
}

void Application::SetListeningMode(
    ListeningMode mode) {

    listening_mode_ = mode;

    SetDeviceState(
        kDeviceStateListening
    );
}

ListeningMode Application::GetDefaultListeningMode() const {
    return aec_mode_ == kAecOff
               ? kListeningModeAutoStop
               : kListeningModeRealtime;
}

void Application::Reboot() {
    ESP_LOGI(
        TAG,
        "Rebooting..."
    );

    if (GetDeviceState() ==
        kDeviceStateNotifying) {

        StopNotification();
    }

    if (protocol_ &&
        protocol_->IsAudioChannelOpened()) {

        protocol_->CloseAudioChannel();
    }

    protocol_.reset();

    audio_service_.Stop();

    vTaskDelay(
        pdMS_TO_TICKS(1000)
    );

    esp_restart();
}

bool Application::UpgradeFirmware(
    const std::string& url,
    const std::string& version) {

    auto& board =
        Board::GetInstance();

    auto display =
        board.GetDisplay();

    std::string upgrade_url =
        url;

    std::string version_info =
        version.empty()
            ? "(Manual upgrade)"
            : version;

    if (GetDeviceState() ==
        kDeviceStateNotifying) {

        StopNotification();
    }

    if (protocol_ &&
        protocol_->IsAudioChannelOpened()) {

        ESP_LOGI(
            TAG,
            "Closing audio channel before firmware upgrade"
        );

        protocol_->CloseAudioChannel();
    }

    ESP_LOGI(
        TAG,
        "Starting firmware upgrade from URL: %s",
        upgrade_url.c_str()
    );

    Alert(
        Lang::Strings::OTA_UPGRADE,
        Lang::Strings::UPGRADING,
        "download",
        Lang::Sounds::OGG_UPGRADE
    );

    vTaskDelay(
        pdMS_TO_TICKS(3000)
    );

    SetDeviceState(
        kDeviceStateUpgrading
    );

    std::string message =
        std::string(
            Lang::Strings::NEW_VERSION
        ) +
        version_info;

    display->SetChatMessage(
        "system",
        message.c_str()
    );

    board.SetPowerSaveLevel(
        PowerSaveLevel::PERFORMANCE
    );

    audio_service_.Stop();

    vTaskDelay(
        pdMS_TO_TICKS(1000)
    );

    bool upgrade_success =
        Ota::Upgrade(
            upgrade_url,
            [this, display](
                int progress,
                size_t speed) {

                char buffer[32];

                snprintf(
                    buffer,
                    sizeof(buffer),
                    "%d%% %uKB/s",
                    progress,
                    speed / 1024
                );

                Schedule(
                    [display,
                     message =
                         std::string(buffer)]() {

                        display->SetChatMessage(
                            "system",
                            message.c_str()
                        );
                    }
                );
            }
        );

    if (!upgrade_success) {
        ESP_LOGE(
            TAG,
            "Firmware upgrade failed, restarting audio service and continuing operation..."
        );

        audio_service_.Start();

        board.SetPowerSaveLevel(
            PowerSaveLevel::LOW_POWER
        );

        Alert(
            Lang::Strings::ERROR,
            Lang::Strings::UPGRADE_FAILED,
            "cancel",
            Lang::Sounds::OGG_EXCLAMATION
        );

        vTaskDelay(
            pdMS_TO_TICKS(3000)
        );

        return false;

    } else {
        ESP_LOGI(
            TAG,
            "Firmware upgrade successful, rebooting..."
        );

        display->SetChatMessage(
            "system",
            "Upgrade successful, rebooting..."
        );

        vTaskDelay(
            pdMS_TO_TICKS(1000)
        );

        Reboot();

        return true;
    }
}

/*
 * External wake-word invocation.
 *
 * This function is safe to call from a board button callback.
 *
 * manual_stop = false:
 *     standard XiaoZhi behaviour.
 *
 * manual_stop = true:
 *     one-shot Lichtblick behaviour.
 */
void Application::RegisterOneShotFinishedCallback(std::function<void()> callback) {
    one_shot_finished_callback_ = std::move(callback);
}

int Application::RegisterStateChangeListener(std::function<void(DeviceState, DeviceState)> callback) {
    return state_machine_.AddStateChangeListener(std::move(callback));
}

void Application::WakeWordInvoke(
    const std::string& wake_word,
    bool manual_stop) {

    if (!protocol_) {
        return;
    }
    if (manual_stop) {
        one_shot_invocation_active_ = true;
        ESP_LOGI(TAG, "One-shot invocation activated");
    }

    auto state = GetDeviceState();

    if (state ==
        kDeviceStateIdle) {

        Schedule(
            [this,
             wake_word,
             manual_stop]() {

                if (GetDeviceState() ==
                    kDeviceStateIdle) {

                    BeginWakeWordInvoke(
                        wake_word,
                        manual_stop
                    );
                }
            }
        );

    } else if (state ==
               kDeviceStateNotifying) {

        Schedule(
            [this,
             wake_word,
             manual_stop]() {

                if (GetDeviceState() ==
                    kDeviceStateNotifying) {

                    StopNotification();

                    BeginWakeWordInvoke(
                        wake_word,
                        manual_stop
                    );
                }
            }
        );

    } else if (state ==
               kDeviceStateSpeaking) {

        Schedule([this]() {
            AbortSpeaking(
                kAbortReasonNone
            );
        });

    } else if (state ==
               kDeviceStateListening) {

        Schedule([this]() {
            if (protocol_) {
                protocol_
                    ->CloseAudioChannel();
            }
        });
    }
}

bool Application::CanEnterSleepMode() {
    if (GetDeviceState() !=
        kDeviceStateIdle) {

        return false;
    }

    if (protocol_ &&
        protocol_->IsAudioChannelOpened()) {

        return false;
    }

    if (!audio_service_.IsIdle()) {
        return false;
    }

    return true;
}

void Application::RegisterMcpBroadcastCallback(
    std::function<void(
        const std::string&)> callback) {

    mcp_broadcast_callback_ =
        std::move(callback);
}

void Application::SendMcpMessage(
    const std::string& payload) {

    Schedule(
        [this, payload]() {
            if (protocol_) {
                protocol_
                    ->SendMcpMessage(
                        payload
                    );
            }

            if (mcp_broadcast_callback_) {
                mcp_broadcast_callback_(
                    payload
                );
            }
        }
    );
}

void Application::SetAecMode(
    AecMode mode) {

    aec_mode_ = mode;

    Schedule([this]() {
        auto& board =
            Board::GetInstance();

        auto display =
            board.GetDisplay();

        switch (aec_mode_) {
            case kAecOff:
                audio_service_
                    .EnableDeviceAec(false);

                display->ShowNotification(
                    Lang::Strings::RTC_MODE_OFF
                );

                break;

            case kAecOnServerSide:
                audio_service_
                    .EnableDeviceAec(false);

                display->ShowNotification(
                    Lang::Strings::RTC_MODE_ON
                );

                break;

            case kAecOnDeviceSide:
                audio_service_
                    .EnableDeviceAec(true);

                display->ShowNotification(
                    Lang::Strings::RTC_MODE_ON
                );

                break;
        }

        if (protocol_ &&
            protocol_->IsAudioChannelOpened()) {

            protocol_->CloseAudioChannel();
        }
    });
}

void Application::PlaySound(
    const std::string_view& sound) {

    audio_service_.PlaySound(
        sound
    );
}

void Application::ResetProtocol() {
    Schedule([this]() {
        if (GetDeviceState() ==
            kDeviceStateNotifying) {

            StopNotification();
        }

        if (protocol_ &&
            protocol_->IsAudioChannelOpened()) {

            protocol_->CloseAudioChannel();
        }

        protocol_.reset();
    });
}