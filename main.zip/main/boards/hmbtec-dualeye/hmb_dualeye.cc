#include "hmb_dualeye.h"
#include "config.h"

#if HMB_DUALEYE_ENABLED

#include <driver/gpio.h>
#include <driver/spi_master.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_random.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <algorithm>
#include <cmath>
#include <cstring>

// ============================================================================
// HMB | TEC - XiaoZhi DualEye Expression Engine
// ============================================================================
static const char* TAG="HmbDualEye";

// ============================================================================
// Display / Geometrie
// ============================================================================
static constexpr int W=HMB_EYE_WIDTH;
static constexpr int H=HMB_EYE_HEIGHT;
static constexpr int N=W*H;

#if HMB_EYE_DISPLAY == HMB_EYE_GC9D01_160
static constexpr int EYE_CX=80;
static constexpr int EYE_CY=80;
static constexpr int EYEBALL_RADIUS=74;
static constexpr int IRIS_RADIUS_1=38;
static constexpr int IRIS_RADIUS_2=31;
static constexpr int IRIS_RADIUS_3=24;
static constexpr int PUPIL_RADIUS=18;
static constexpr int HIGHLIGHT1_X=-10;
static constexpr int HIGHLIGHT1_Y=-11;
static constexpr int HIGHLIGHT1_R=7;
static constexpr int HIGHLIGHT2_X=9;
static constexpr int HIGHLIGHT2_Y=8;
static constexpr int HIGHLIGHT2_R=3;
static constexpr float LOOK_X_MAX=23.0f;
static constexpr float LOOK_Y_MAX=18.0f;
static constexpr int BLINK_DEPTH=82;
#elif HMB_EYE_DISPLAY == HMB_EYE_GC9A01_240
static constexpr int EYE_CX=120;
static constexpr int EYE_CY=120;
static constexpr int EYEBALL_RADIUS=112;
static constexpr int IRIS_RADIUS_1=57;
static constexpr int IRIS_RADIUS_2=47;
static constexpr int IRIS_RADIUS_3=36;
static constexpr int PUPIL_RADIUS=27;
static constexpr int HIGHLIGHT1_X=-15;
static constexpr int HIGHLIGHT1_Y=-17;
static constexpr int HIGHLIGHT1_R=10;
static constexpr int HIGHLIGHT2_X=14;
static constexpr int HIGHLIGHT2_Y=12;
static constexpr int HIGHLIGHT2_R=5;
static constexpr float LOOK_X_MAX=35.0f;
static constexpr float LOOK_Y_MAX=27.0f;
static constexpr int BLINK_DEPTH=123;
#else
#error "Unsupported HMB DualEye display"
#endif

// ============================================================================
// Farben RGB565
// ============================================================================
static constexpr uint16_t BLACK=0x0000;
static constexpr uint16_t WHITE=0xFFFF;
static constexpr uint16_t IRIS1=0x067F;
static constexpr uint16_t IRIS2=0x04FC;
static constexpr uint16_t IRIS3=0x0255;

// ============================================================================
// Framebuffer / SPI
// ============================================================================
static uint16_t* fb=nullptr;
static spi_device_handle_t devL=nullptr;
static spi_device_handle_t devR=nullptr;

// ============================================================================
// Eye State
// ============================================================================
static volatile DeviceState eyeState=kDeviceStateIdle;
static volatile HmbEyeExpression eyeExpression=HmbEyeExpression::Neutral;
static volatile int64_t expressionUntil=0;
static volatile HmbEyeLook eyeLook=HmbEyeLook::Auto;
static volatile int64_t lookUntil=0;
static float px=0.0f;
static float py=0.0f;
static float tx=0.0f;
static float ty=0.0f;
static float blink=0.0f;
static bool closing=false;
static int64_t nextLook=0;
static int64_t nextBlink=0;

// ============================================================================
// SPI Low Level
// ============================================================================
static void txBytes(spi_device_handle_t d,const void* data,size_t len){
    spi_transaction_t t={};
    t.length=len*8;
    t.tx_buffer=data;
    ESP_ERROR_CHECK(spi_device_polling_transmit(d,&t));
}
static void cmd(spi_device_handle_t d,uint8_t c){
    gpio_set_level(HMB_EYE_DC,0);
    txBytes(d,&c,1);
}
static void data(spi_device_handle_t d,const void* p,size_t n){
    gpio_set_level(HMB_EYE_DC,1);
    txBytes(d,p,n);
}
static void cd(spi_device_handle_t d,uint8_t c,const uint8_t* p,size_t n){
    cmd(d,c);
    if(n) data(d,p,n);
}
static void write8(spi_device_handle_t d,uint8_t command,uint8_t value){
    cd(d,command,&value,1);
}

// ============================================================================
// GC9D01 Initialisierung
// ============================================================================
static void initGC9D01(spi_device_handle_t d,bool rotate180){
    cmd(d,0xFE);
    cmd(d,0xEF);
    for(uint8_t r=0x80;r<=0x8F;r++){
        uint8_t v=0xFF;
        cd(d,r,&v,1);
    }
    uint8_t v;
    v=0x05; cd(d,0x3A,&v,1);
    v=0x01; cd(d,0xEC,&v,1);
    const uint8_t a74[]={0x02,0x0E,0x00,0x00,0x00,0x00,0x00}; cd(d,0x74,a74,sizeof(a74));
    v=0x3E; cd(d,0x98,&v,1); cd(d,0x99,&v,1);
    const uint8_t b5[]={0x0D,0x0D}; cd(d,0xB5,b5,sizeof(b5));
    const uint8_t a60[]={0x38,0x0F,0x79,0x67}; cd(d,0x60,a60,sizeof(a60));
    const uint8_t a61[]={0x38,0x11,0x79,0x67}; cd(d,0x61,a61,sizeof(a61));
    const uint8_t a64[]={0x38,0x17,0x71,0x5F,0x79,0x67}; cd(d,0x64,a64,sizeof(a64));
    const uint8_t a65[]={0x38,0x13,0x71,0x5B,0x79,0x67}; cd(d,0x65,a65,sizeof(a65));
    const uint8_t a6a[]={0x00,0x00}; cd(d,0x6A,a6a,sizeof(a6a));
    const uint8_t a6c[]={0x22,0x02,0x22,0x02,0x22,0x22,0x50}; cd(d,0x6C,a6c,sizeof(a6c));
    const uint8_t a6e[]={
        0x03,0x03,0x01,0x01,0x00,0x00,0x0F,0x0F,0x0D,0x0D,0x0B,0x0B,0x09,0x09,0x00,0x00,
        0x00,0x00,0x0A,0x0A,0x0C,0x0C,0x0E,0x0E,0x10,0x10,0x00,0x00,0x02,0x02,0x04,0x04
    }; cd(d,0x6E,a6e,sizeof(a6e));
    v=0x01; cd(d,0xBF,&v,1);
    v=0x40; cd(d,0xF9,&v,1);
    v=0x3B; cd(d,0x9B,&v,1);
    const uint8_t a93[]={0x33,0x7F,0x00}; cd(d,0x93,a93,sizeof(a93));
    v=0x30; cd(d,0x7E,&v,1);
    const uint8_t a70[]={0x0D,0x02,0x08,0x0D,0x02,0x08}; cd(d,0x70,a70,sizeof(a70));
    const uint8_t a71[]={0x0D,0x02,0x08}; cd(d,0x71,a71,sizeof(a71));
    const uint8_t a91[]={0x0E,0x09}; cd(d,0x91,a91,sizeof(a91));
    v=0x19; cd(d,0xC3,&v,1); cd(d,0xC4,&v,1);
    v=0x3C; cd(d,0xC9,&v,1);
    const uint8_t f0[]={0x53,0x15,0x0A,0x04,0x00,0x3E}; cd(d,0xF0,f0,sizeof(f0));
    const uint8_t f2[]={0x53,0x15,0x0A,0x04,0x00,0x3A}; cd(d,0xF2,f2,sizeof(f2));
    const uint8_t f1[]={0x56,0xA8,0x7F,0x33,0x34,0x5F}; cd(d,0xF1,f1,sizeof(f1));
    const uint8_t f3[]={0x52,0xA4,0x7F,0x33,0x34,0xDF}; cd(d,0xF3,f3,sizeof(f3));

    // Individuelle Orientierung der beiden physischen GC9D01.
    v=rotate180 ? 0xA0 : 0x60;
    cd(d,0x36,&v,1);

    // Sleep Out
    cmd(d,0x11);
    vTaskDelay(pdMS_TO_TICKS(200));

    // Display On
    cmd(d,0x29);
    vTaskDelay(pdMS_TO_TICKS(20));
}

// ============================================================================
// GC9A01 Initialisierung
// ============================================================================
static void initGC9A01(spi_device_handle_t d){
    cmd(d,0x01);
    vTaskDelay(pdMS_TO_TICKS(120));
    cmd(d,0xEF);
    write8(d,0xEB,0x14);
    cmd(d,0xFE);
    cmd(d,0xEF);
    write8(d,0xEB,0x14);
    write8(d,0x84,0x40); write8(d,0x85,0xFF); write8(d,0x86,0xFF); write8(d,0x87,0xFF);
    write8(d,0x88,0x0A); write8(d,0x89,0x21); write8(d,0x8A,0x00); write8(d,0x8B,0x80);
    write8(d,0x8C,0x01); write8(d,0x8D,0x01); write8(d,0x8E,0xFF); write8(d,0x8F,0xFF);
    const uint8_t b6[]={0x00,0x20}; cd(d,0xB6,b6,sizeof(b6));
    write8(d,0x36,0x08);
    write8(d,0x3A,0x05);
    const uint8_t a90[]={0x08,0x08,0x08,0x08}; cd(d,0x90,a90,sizeof(a90));
    write8(d,0xBD,0x06); write8(d,0xBC,0x00);
    const uint8_t ff[]={0x60,0x01,0x04}; cd(d,0xFF,ff,sizeof(ff));
    write8(d,0xC3,0x13); write8(d,0xC4,0x13); write8(d,0xC9,0x22); write8(d,0xBE,0x11);
    const uint8_t e1[]={0x10,0x0E}; cd(d,0xE1,e1,sizeof(e1));
    const uint8_t df[]={0x21,0x0C,0x02}; cd(d,0xDF,df,sizeof(df));
    const uint8_t f0[]={0x45,0x09,0x08,0x08,0x26,0x2A}; cd(d,0xF0,f0,sizeof(f0));
    const uint8_t f1[]={0x43,0x70,0x72,0x36,0x37,0x6F}; cd(d,0xF1,f1,sizeof(f1));
    const uint8_t f2[]={0x45,0x09,0x08,0x08,0x26,0x2A}; cd(d,0xF2,f2,sizeof(f2));
    const uint8_t f3[]={0x43,0x70,0x72,0x36,0x37,0x6F}; cd(d,0xF3,f3,sizeof(f3));
    const uint8_t ed[]={0x1B,0x0B}; cd(d,0xED,ed,sizeof(ed));
    write8(d,0xAE,0x77); write8(d,0xCD,0x63);
    const uint8_t a70[]={0x07,0x07,0x04,0x0E,0x0F,0x09,0x07,0x08,0x03}; cd(d,0x70,a70,sizeof(a70));
    write8(d,0xE8,0x34);
    const uint8_t a62[]={0x18,0x0D,0x71,0xED,0x70,0x70,0x18,0x0F,0x71,0xEF,0x70,0x70}; cd(d,0x62,a62,sizeof(a62));
    const uint8_t a63[]={0x18,0x11,0x71,0xF1,0x70,0x70,0x18,0x13,0x71,0xF3,0x70,0x70}; cd(d,0x63,a63,sizeof(a63));
    const uint8_t a64[]={0x28,0x29,0xF1,0x01,0xF1,0x00,0x07}; cd(d,0x64,a64,sizeof(a64));
    const uint8_t a66[]={0x3C,0x00,0xCD,0x67,0x45,0x45,0x10,0x00,0x00,0x00}; cd(d,0x66,a66,sizeof(a66));
    const uint8_t a67[]={0x00,0x3C,0x00,0x00,0x00,0x01,0x54,0x10,0x32,0x98}; cd(d,0x67,a67,sizeof(a67));
    const uint8_t a74[]={0x10,0x85,0x80,0x00,0x00,0x4E,0x00}; cd(d,0x74,a74,sizeof(a74));
    const uint8_t a98[]={0x3E,0x07}; cd(d,0x98,a98,sizeof(a98));
    cmd(d,0x34);
    cmd(d,0x21);
    cmd(d,0x11);
    vTaskDelay(pdMS_TO_TICKS(120));
    cmd(d,0x29);
    vTaskDelay(pdMS_TO_TICKS(20));
}

static void initPanel(spi_device_handle_t d,bool rotate180){
#if HMB_EYE_DISPLAY == HMB_EYE_GC9D01_160
    uint8_t madctl=rotate180 ? 0xA0 : 0x60;
    ESP_LOGI(TAG,"Initializing GC9D01 160x160, MADCTL=0x%02X",madctl);
    initGC9D01(d,rotate180);
#elif HMB_EYE_DISPLAY == HMB_EYE_GC9A01_240
    ESP_LOGI(TAG,"Initializing GC9A01 240x240");
    initGC9A01(d);
#endif
}

// ============================================================================
// Primitive Grafikfunktionen
// ============================================================================
static void hline(int x,int y,int w,uint16_t c){
    if(y<0 || y>=H || w<=0) return;
    if(x<0){
        w+=x;
        x=0;
    }
    if(x+w>W) w=W-x;
    if(w<=0) return;
    for(int i=0;i<w;i++) fb[y*W+x+i]=c;
}
static void circle(int cx,int cy,int r,uint16_t c){
    int r2=r*r;
    for(int y=-r;y<=r;y++){
        int yy=r2-y*y;
        if(yy<0) continue;
        int x=(int)sqrtf((float)yy);
        hline(cx-x,cy+y,x*2+1,c);
    }
}

// ============================================================================
// Expression Masken
// ============================================================================
static void maskTopFlat(int depth){
    for(int y=0;y<depth;y++) hline(0,y,W,BLACK);
}
static void maskBottomFlat(int depth){
    for(int y=0;y<depth;y++) hline(0,H-1-y,W,BLACK);
}
static void maskTopSlope(int baseDepth,int slope,bool mirror){
    for(int x=0;x<W;x++){
        float nx=(float)x/(float)(W-1);
        if(mirror) nx=1.0f-nx;
        int depth=baseDepth+(int)((nx-0.5f)*(float)slope);
        depth=std::max(0,std::min(H,depth));
        for(int y=0;y<depth;y++) fb[y*W+x]=BLACK;
    }
}

// ============================================================================
// Auge rendern
// ============================================================================
// Beide Augen verwenden immer exakt dieselben Pupillenkoordinaten px/py.
// leftEye beeinflusst nur bewusst asymmetrische Lid-Expressions wie Confused.
static void render(bool leftEye,HmbEyeExpression expression){
    std::fill_n(fb,N,BLACK);

    float ex=px;
    float ey=py;
    int pupil=PUPIL_RADIUS;

    switch(expression){
        case HmbEyeExpression::Thinking:
            ey-=0.45f*LOOK_Y_MAX;
            break;
        case HmbEyeExpression::Curious:
            ey-=0.18f*LOOK_Y_MAX;
            break;
        case HmbEyeExpression::Surprised:
            ex=0.0f;
            ey=0.0f;
            pupil=(int)(PUPIL_RADIUS*1.18f);
            break;
        case HmbEyeExpression::Sad:
            ey+=0.28f*LOOK_Y_MAX;
            break;
        case HmbEyeExpression::Confused:
            break;
        case HmbEyeExpression::Sleepy:
            ey+=0.15f*LOOK_Y_MAX;
            break;
        default:
            break;
    }

    ex=std::max(-LOOK_X_MAX,std::min(LOOK_X_MAX,ex));
    ey=std::max(-LOOK_Y_MAX,std::min(LOOK_Y_MAX,ey));

    circle(EYE_CX,EYE_CY,EYEBALL_RADIUS,WHITE);

    int ix=EYE_CX+(int)ex;
    int iy=EYE_CY+(int)ey;

    circle(ix,iy,IRIS_RADIUS_1,IRIS1);
    circle(ix,iy,IRIS_RADIUS_2,IRIS2);
    circle(ix,iy,IRIS_RADIUS_3,IRIS3);
    circle(ix,iy,pupil,BLACK);
    circle(ix+HIGHLIGHT1_X,iy+HIGHLIGHT1_Y,HIGHLIGHT1_R,WHITE);
    circle(ix+HIGHLIGHT2_X,iy+HIGHLIGHT2_Y,HIGHLIGHT2_R,WHITE);

    // Semantische Lidstellung
    switch(expression){
        case HmbEyeExpression::Happy:
            maskBottomFlat((int)(H*0.13f));
            maskTopFlat((int)(H*0.05f));
            break;
        case HmbEyeExpression::Relaxed:
            maskTopFlat((int)(H*0.11f));
            maskBottomFlat((int)(H*0.04f));
            break;
        case HmbEyeExpression::Curious:
            maskTopFlat((int)(H*0.055f));
            break;
        case HmbEyeExpression::Thinking:
            maskTopSlope((int)(H*0.07f),(int)(H*0.08f),false);
            break;
        case HmbEyeExpression::Sad:
            maskTopSlope((int)(H*0.10f),(int)(H*0.15f),false);
            break;
        case HmbEyeExpression::Confused:
            if(leftEye) maskTopSlope((int)(H*0.05f),(int)(H*0.12f),false);
            else maskTopFlat((int)(H*0.12f));
            break;
        case HmbEyeExpression::Sleepy:
            maskTopFlat((int)(H*0.27f));
            maskBottomFlat((int)(H*0.08f));
            break;
        default:
            break;
    }

    // Natürliches Blinzeln liegt über jeder Expression
    int lid=(int)((float)BLINK_DEPTH*blink);
    for(int y=0;y<lid;y++){
        float f=1.0f-(float)y/(float)BLINK_DEPTH;
        int in=(int)((float)W*0.0625f*f);
        hline(in,y,W-in*2,BLACK);
        hline(in,H-1-y,W-in*2,BLACK);
    }
}

// ============================================================================
// Frame an Display übertragen
// ============================================================================
static void push(spi_device_handle_t d,bool mirror=false){
    uint16_t xEnd=W-1;
    uint16_t yEnd=H-1;
    const uint8_t col[]={0x00,0x00,(uint8_t)(xEnd>>8),(uint8_t)(xEnd&0xFF)};
    const uint8_t row[]={0x00,0x00,(uint8_t)(yEnd>>8),(uint8_t)(yEnd&0xFF)};
    cd(d,0x2A,col,sizeof(col));
    cd(d,0x2B,row,sizeof(row));
    cmd(d,0x2C);
    gpio_set_level(HMB_EYE_DC,1);
    static uint8_t line[W*2];
    for(int y=0;y<H;y++){
        for(int x=0;x<W;x++){
            uint16_t c=fb[y*W+(mirror?(W-1-x):x)];
            line[x*2]=(uint8_t)(c>>8);
            line[x*2+1]=(uint8_t)(c&0xFF);
        }
        txBytes(d,line,sizeof(line));
        if((y&15)==15) vTaskDelay(1); // IDLE0 darf laufen, auch bei langer SPI-Uebertragung
    }
}

// ============================================================================
// Zufall / Expression
// ============================================================================
static int randomSigned(int minimum,int maximum){
    uint32_t range=(uint32_t)(maximum-minimum+1);
    return (int)(esp_random()%range)+minimum;
}
static const char* expressionName(HmbEyeExpression e){
    switch(e){
        case HmbEyeExpression::Happy: return "happy";
        case HmbEyeExpression::Relaxed: return "relaxed";
        case HmbEyeExpression::Curious: return "curious";
        case HmbEyeExpression::Thinking: return "thinking";
        case HmbEyeExpression::Surprised: return "surprised";
        case HmbEyeExpression::Sad: return "sad";
        case HmbEyeExpression::Confused: return "confused";
        case HmbEyeExpression::Sleepy: return "sleepy";
        default: return "neutral";
    }
}
static const char* lookName(HmbEyeLook look){
    switch(look){
        case HmbEyeLook::Center: return "center";
        case HmbEyeLook::Left: return "left";
        case HmbEyeLook::Right: return "right";
        case HmbEyeLook::Up: return "up";
        case HmbEyeLook::Down: return "down";
        case HmbEyeLook::UpLeft: return "up_left";
        case HmbEyeLook::UpRight: return "up_right";
        case HmbEyeLook::DownLeft: return "down_left";
        case HmbEyeLook::DownRight: return "down_right";
        default: return "auto";
    }
}
static void applyLookTarget(HmbEyeLook look){
    switch(look){
        case HmbEyeLook::Center: tx=0.0f; ty=0.0f; break;
        case HmbEyeLook::Left: tx=-LOOK_X_MAX; ty=0.0f; break;
        case HmbEyeLook::Right: tx=LOOK_X_MAX; ty=0.0f; break;
        case HmbEyeLook::Up: tx=0.0f; ty=-LOOK_Y_MAX; break;
        case HmbEyeLook::Down: tx=0.0f; ty=LOOK_Y_MAX; break;
        case HmbEyeLook::UpLeft: tx=-LOOK_X_MAX*0.82f; ty=-LOOK_Y_MAX*0.82f; break;
        case HmbEyeLook::UpRight: tx=LOOK_X_MAX*0.82f; ty=-LOOK_Y_MAX*0.82f; break;
        case HmbEyeLook::DownLeft: tx=-LOOK_X_MAX*0.82f; ty=LOOK_Y_MAX*0.82f; break;
        case HmbEyeLook::DownRight: tx=LOOK_X_MAX*0.82f; ty=LOOK_Y_MAX*0.82f; break;
        default: break;
    }
}

// ============================================================================
// Eye Animation Task
// ============================================================================
// HMB FlameEngine: prozedurale Flamme, ein Framebuffer, zwei gespiegelte Ausgaben.
// Keine Frame-Assets im Flash; keine zweite Bildkopie im RAM.
#if HMB_DISPLAY_MODE == 1
// Steuerung wird unter einem kurzen Spinlock kopiert; Rendering bleibt lockfrei.
static portMUX_TYPE moodMux=portMUX_INITIALIZER_UNLOCKED;
static uint32_t moodColor=HMB_FLAME_MOOD_DEFAULT_COLOR;
static uint8_t moodIntensity=HMB_FLAME_MOOD_DEFAULT_INTENSITY;
static uint32_t moodTransitionMs=HMB_FLAME_MOOD_TRANSITION_MS;
static float moodCurrentR=0.0f,moodCurrentG=0.0f,moodCurrentB=0.0f;
static float moodCurrentIntensity=0.0f;
static int64_t moodLastFrameUs=0;
void HmbFlameSetMoodColor(uint32_t rgb){
    portENTER_CRITICAL(&moodMux);
    moodColor=rgb&0xFFFFFFu;
    portEXIT_CRITICAL(&moodMux);
}
void HmbFlameSetMoodIntensity(uint8_t intensity){
    portENTER_CRITICAL(&moodMux);
    moodIntensity=std::min<uint8_t>(intensity,100);
    portEXIT_CRITICAL(&moodMux);
}
void HmbFlameSetMoodTransition(uint32_t milliseconds){
    portENTER_CRITICAL(&moodMux);
    moodTransitionMs=milliseconds;
    portEXIT_CRITICAL(&moodMux);
}
static void updateMood(int64_t nowUs){
    uint32_t color,transition;
    uint8_t intensity;
    portENTER_CRITICAL(&moodMux);
    color=moodColor; intensity=moodIntensity; transition=moodTransitionMs;
    portEXIT_CRITICAL(&moodMux);
    float deltaMs=(moodLastFrameUs>0)?fminf(250.0f,(nowUs-moodLastFrameUs)/1000.0f):0.0f;
    moodLastFrameUs=nowUs;
    float step=(transition==0)?1.0f:fminf(1.0f,deltaMs/(float)transition);
    // Exponentielles, sanftes Einblenden ohne sichtbare Farbspruenge.
    moodCurrentR+=(((color>>16)&255)-moodCurrentR)*step;
    moodCurrentG+=(((color>>8)&255)-moodCurrentG)*step;
    moodCurrentB+=((color&255)-moodCurrentB)*step;
    moodCurrentIntensity+=((float)intensity-moodCurrentIntensity)*step;
}
#else
void HmbFlameSetMoodColor(uint32_t){}
void HmbFlameSetMoodIntensity(uint8_t){}
void HmbFlameSetMoodTransition(uint32_t){}
#endif

#if HMB_DISPLAY_MODE == 1
#if HMB_FLAME_SPARKLE_EN
struct HmbSparkle{
    float x=0.0f,y=0.0f;
    int64_t startUs=0;
    uint32_t durationMs=0;
    bool star=false;
    bool active=false;
};
static HmbSparkle sparkles[HMB_FLAME_SPARKLE_MAX_ACTIVE];
static int64_t sparkleNextUs=0;
static uint32_t sparkleEvents=0;
static uint32_t sparkleRandomRange(uint32_t lo,uint32_t hi){
    return lo+(esp_random()%(hi-lo+1));
}
static void updateSparkles(int64_t nowUs){
    for(auto &s:sparkles){
        if(s.active && nowUs-s.startUs>=(int64_t)s.durationMs*1000) s.active=false;
    }
    if(sparkleNextUs==0) sparkleNextUs=nowUs+(int64_t)(HMB_FLAME_SPARKLE_TEST_MODE?1000:sparkleRandomRange(HMB_FLAME_SPARKLE_MIN_MS,HMB_FLAME_SPARKLE_MAX_MS))*1000;
    if(nowUs<sparkleNextUs) return;
    // Meist ein Stern, gelegentlich zwei, selten drei oder vier.
    const uint32_t roll=sparkleRandomRange(0,99);
    const int requested=HMB_FLAME_SPARKLE_TEST_MODE?2:(roll<2?4:(roll<10?3:(roll<35?2:1)));
    const int countLimit=requested<HMB_FLAME_SPARKLE_MAX_ACTIVE?requested:HMB_FLAME_SPARKLE_MAX_ACTIVE;
    int created=0;
    float firstX=0.0f,firstY=0.0f;
    uint32_t firstDuration=0;
    for(auto &s:sparkles){
        if(created>=countLimit) break;
        if(s.active) continue; // Laufende und vorgemerkte Sterne nicht ueberschreiben.
        const bool left=sparkleRandomRange(0,1)==0;
        s.x=(float)(left?sparkleRandomRange(65,86):sparkleRandomRange(154,175));
        s.y=(float)sparkleRandomRange(53,83);
        // Kurze zufaellige Staffelung statt gleichzeitiger Aktivierung.
        s.startUs=nowUs+(int64_t)(created==0?0:sparkleRandomRange(200,950)*created)*1000;
        s.durationMs=HMB_FLAME_SPARKLE_TEST_MODE?3500:sparkleRandomRange(1400,2400);
        s.star=sparkleRandomRange(0,99)<HMB_FLAME_SPARKLE_STAR_CHANCE;
        s.active=true;
        if(created==0){firstX=s.x;firstY=s.y;firstDuration=s.durationMs;}
        ++created;
    }
    ++sparkleEvents;
    sparkleNextUs=nowUs+(int64_t)(HMB_FLAME_SPARKLE_TEST_MODE?5000:sparkleRandomRange(HMB_FLAME_SPARKLE_MIN_MS,HMB_FLAME_SPARKLE_MAX_MS))*1000;
    ESP_LOGI(TAG,"MagicSparkle event=%lu requested=%d created=%d first=(%.0f,%.0f) duration=%lu ms",(unsigned long)sparkleEvents,requested,created,firstX,firstY,(unsigned long)firstDuration);
}
static float sparkleAt(int x,int y,int64_t nowUs){
    float light=0.0f;
    for(const auto &s:sparkles){
        if(!s.active || nowUs<s.startUs) continue;
        float progress=(float)(nowUs-s.startUs)/((float)s.durationMs*1000.0f);
        if(progress<0.0f || progress>=1.0f) continue;
        float fade=(progress<0.28f)?(progress/0.28f):((1.0f-progress)/0.72f);
        float dx=fabsf(x-s.x),dy=fabsf(y-s.y);

    if(dx>22.0f || dy>22.0f) continue;
    float d2=dx*dx+dy*dy;
    float core=expf(-d2/28.0f);
    float rays=0.0f;
    if(s.star){
        rays=fmaxf(
            expf(-dy*dy/3.0f)*expf(-dx*dx/110.0f),
            expf(-dx*dx/3.0f)*expf(-dy*dy/110.0f)
        )*0.95f;
    }        
        light=fmaxf(light,fminf(1.0f,(core+rays)*fade));
    }
    return light*(HMB_FLAME_SPARKLE_INTENSITY/100.0f);
}
#endif
static void renderFlame(float t,DeviceState state){
    const int64_t frameUs=esp_timer_get_time();
    updateMood(frameUs);
#if HMB_FLAME_SPARKLE_EN
    updateSparkles(frameUs);
#endif
    const float activity=(state==kDeviceStateSpeaking)?1.3f:((state==kDeviceStateListening)?0.5f:1.0f);
    const float sway=(sinf(t*1.9f)*5.0f+sinf(t*3.17f+0.7f)*2.3f)*activity;
    const float flicker=0.96f+0.035f*sinf(t*7.1f)+0.02f*sinf(t*12.3f);
    const float scale=HMB_FLAME_SCALE_PERCENT/100.0f;
    const float baseY=211.0f;
    const float height=151.0f*scale*flicker;
    const float auraStrength=HMB_FLAME_AURA_STRENGTH/100.0f;
    const float auraRadius=(float)HMB_FLAME_AURA_RADIUS;
    // Teure trigonometrische und Potenzfunktionen nur einmal pro Bildzeile.
    const float moodStrength=moodCurrentIntensity/100.0f*0.62f;
    float moodX[W];
    for(int x=0;x<W;x++){
        const float nx=((float)x-W*0.5f)/(float)W;
        const float ax=(fabsf(nx)-0.33f)/0.19f;
        const float mask=fminf(1.0f,fmaxf(0.0f,(fabsf(nx)-0.11f)/0.13f));
        moodX[x]=expf(-2.0f*ax*ax)*mask;
    }
    for(int y=0;y<H;y++){
        float u=(baseY-y)/height;
        const float uc=fmaxf(0.0f,fminf(1.0f,u));
        const bool flameRow=(u>-0.25f && u<1.23f);
        const float bend=flameRow?(sway*uc*uc+2.2f*sinf(t*3.7f+uc*5.0f)*uc*uc):0.0f;
        const float cx=W*0.5f+bend;
        float width=0.0f;
        if(flameRow){
            width=(3.0f+33.0f*powf(fmaxf(0.0f,1.0f-uc),0.72f)*sinf(3.14159265f*powf(uc,0.64f)))*scale;
            width*=1.0f+0.07f*sinf(t*4.9f+uc*8.0f);
        }
        const float cap=fminf(1.0f,fmaxf(0.0f,(baseY-y)/9.0f))*fminf(1.0f,fmaxf(0.0f,(baseY-height*0.99f-y)/(-height*0.01f)));
        const float glowMod=0.72f+0.28f*sinf(3.14159265f*uc);
        const float vertical=(u<0.0f)?(-u*height):((u>1.0f)?((u-1.0f)*height):0.0f);
        const float ny=((float)y-H*0.56f)/(float)H;
        const float ay=ny/0.33f;
        const float moodY=expf(-2.0f*ay*ay)*moodStrength;
        const float wickX=W*0.5f+1.3f*sinf((baseY-5.0f-y)*0.16f);
        const float emberX=W*0.5f+1.3f*sinf(13.0f*0.16f);
        const float ey=y-(baseY-15.0f);
        const float emberY=expf(-ey*ey/8.0f);
        for(int x=0;x<W;x++){
            float r=0.0f,g=0.0f,b=0.0f;
#if HMB_FLAME_MOOD_EN
            // Zwei diffuse, seitliche Farbfelder. Nicht im Zentrum der Flamme.
            // Maximalintensitaet bewusst gering: Mood bleibt Hintergrundlicht.
            const float moodLevel=moodX[x]*moodY;
            r+=moodCurrentR*moodLevel;
            g+=moodCurrentG*moodLevel;
            b+=moodCurrentB*moodLevel;
#endif
            if(flameRow){
                float dx=fabsf((float)x-cx);
                float inside=(width-dx)/3.0f;
                float alpha=fmaxf(0.0f,fminf(1.0f,inside))*cap;
#if HMB_FLAME_AURA_EN
                // Konturfolgende, weich auslaufende Aura; keine zusätzliche Bilddatei.
                float dist=fmaxf(0.0f,dx-width);
                float d=sqrtf(dist*dist+vertical*vertical);
                float glow=expf(-d*d/(2.0f*auraRadius*auraRadius))*auraStrength;
                glow*=glowMod;
                r+=35.0f*glow; g+=11.0f*glow; b+=1.5f*glow;
#endif
                if(alpha>0.0f){
                    float core=fmaxf(0.0f,1.0f-dx/(width*0.66f+0.1f));
                    float blue=fmaxf(0.0f,1.0f-uc/0.105f);
                    float red=255.0f;
                    float green=100.0f+150.0f*core+22.0f*uc;
                    float blu=5.0f+85.0f*core;
                    red=red*(1.0f-blue)+45.0f*blue;
                    green=green*(1.0f-blue)+115.0f*blue;
                    blu=blu*(1.0f-blue)+210.0f*blue;
                    r=r*(1.0f-alpha)+red*alpha;
                    g=g*(1.0f-alpha)+green*alpha;
                    b=b*(1.0f-alpha)+blu*alpha;
                }
            }
            // Angedeuteter, leicht gebogener Docht, sichtbar im unteren Flammenbereich.
            float wickY=baseY-5.0f;
            if(y>=baseY-18.0f && y<=baseY+2.0f && fabsf(x-wickX)<1.65f){
                r=17.0f;g=15.0f;b=13.0f;
            }
            float ex=x-emberX;
            float ember=expf(-ex*ex/8.0f)*emberY;
            r=fmaxf(r,240.0f*ember);g=fmaxf(g,70.0f*ember);b=fmaxf(b,7.0f*ember);
#if HMB_FLAME_SPARKLE_EN
            // Grosser Stern mit weichen Strahlen; im Testmodus einzeln links/rechts.
            float sparkle=sparkleAt(x,y,frameUs);
            r+=255.0f*sparkle;g+=235.0f*sparkle;b+=180.0f*sparkle;
#endif
            uint8_t R=(uint8_t)fminf(255.0f,fmaxf(0.0f,r));
            uint8_t G=(uint8_t)fminf(255.0f,fmaxf(0.0f,g));
            uint8_t B=(uint8_t)fminf(255.0f,fmaxf(0.0f,b));
            fb[y*W+x]=((R&0xF8)<<8)|((G&0xFC)<<3)|(B>>3);
        }
        if((y&15)==15) vTaskDelay(1); // IDLE0 auch waehrend rechenintensivem Rendering
    }
}
#endif

static void task(void*){
    nextLook=esp_timer_get_time()/1000+800;
    nextBlink=esp_timer_get_time()/1000+3000;

    while(true){
#if HMB_DISPLAY_MODE == 1
        const int64_t frameStart=esp_timer_get_time();
        renderFlame((float)frameStart/1000000.0f,eyeState);
        const int64_t renderEnd=esp_timer_get_time();
        push(devL,false);
        push(devR,HMB_FLAME_BACK_MIRROR!=0);
        const int64_t frameEnd=esp_timer_get_time();
        static uint32_t frameCount=0;
        static int64_t totalFrameUs=0,totalRenderUs=0,totalPushUs=0;
        totalFrameUs+=frameEnd-frameStart;
        totalRenderUs+=renderEnd-frameStart;
        totalPushUs+=frameEnd-renderEnd;
        if(++frameCount>=120){
            ESP_LOGI(TAG,"Flame timing avg: render=%lld ms SPI=%lld ms total=%lld ms",(long long)(totalRenderUs/120/1000),(long long)(totalPushUs/120/1000),(long long)(totalFrameUs/120/1000));
            frameCount=0;totalFrameUs=0;totalRenderUs=0;totalPushUs=0;
        }
        // 30 FPS als Obergrenze; keine zusaetzliche feste 45-ms-Wartezeit.
        const int64_t remainingUs=33333-(esp_timer_get_time()-frameStart);
        if(remainingUs>1000) vTaskDelay(pdMS_TO_TICKS((remainingUs+999)/1000));
        else vTaskDelay(1); // taskYIELD allein gibt IDLE0 nicht verlaesslich CPU-Zeit
        continue;
#endif
        int64_t now=esp_timer_get_time()/1000;
        DeviceState s=eyeState;
        HmbEyeExpression expression=eyeExpression;
        HmbEyeLook look=eyeLook;

        if(look!=HmbEyeLook::Auto && lookUntil>0 && now>=lookUntil){
            eyeLook=HmbEyeLook::Auto;
            lookUntil=0;
            look=HmbEyeLook::Auto;
            nextLook=now;
            ESP_LOGI(TAG,"Look timeout -> auto");
        }

        if(expression!=HmbEyeExpression::Neutral && expressionUntil>0 && now>=expressionUntil){
            eyeExpression=HmbEyeExpression::Neutral;
            expressionUntil=0;
            expression=HmbEyeExpression::Neutral;
            ESP_LOGI(TAG,"Expression timeout -> neutral");
        }

        // Explizite Blickrichtung hat Vorrang vor Expression und DeviceState.
        if(look!=HmbEyeLook::Auto){
            applyLookTarget(look);
        }
        // Expression beeinflusst Blickverhalten, DeviceState bleibt Fallback.
        else if(expression==HmbEyeExpression::Surprised){
            tx=0.0f;
            ty=0.0f;
        }
        else if(expression==HmbEyeExpression::Thinking){
            if(now>=nextLook){
                tx=(float)randomSigned(-(int)(LOOK_X_MAX*0.35f),(int)(LOOK_X_MAX*0.35f));
                ty=-(LOOK_Y_MAX*0.55f);
                nextLook=now+1200;
            }
        }
        else if(expression==HmbEyeExpression::Curious){
            if(now>=nextLook){
                tx=(float)randomSigned(-(int)(LOOK_X_MAX*0.55f),(int)(LOOK_X_MAX*0.55f));
                ty=(float)randomSigned(-(int)(LOOK_Y_MAX*0.30f),(int)(LOOK_Y_MAX*0.15f));
                nextLook=now+900;
            }
        }
        else if(expression==HmbEyeExpression::Sad){
            if(now>=nextLook){
                tx=(float)randomSigned(-(int)(LOOK_X_MAX*0.25f),(int)(LOOK_X_MAX*0.25f));
                ty=LOOK_Y_MAX*0.35f;
                nextLook=now+1400;
            }
        }
        else if(expression==HmbEyeExpression::Confused){
            if(now>=nextLook){
                tx=(float)randomSigned(-(int)(LOOK_X_MAX*0.45f),(int)(LOOK_X_MAX*0.45f));
                ty=(float)randomSigned(-(int)(LOOK_Y_MAX*0.20f),(int)(LOOK_Y_MAX*0.20f));
                nextLook=now+650;
            }
        }
        else if(expression==HmbEyeExpression::Sleepy){
            if(now>=nextLook){
                tx=(float)randomSigned(-(int)(LOOK_X_MAX*0.18f),(int)(LOOK_X_MAX*0.18f));
                ty=LOOK_Y_MAX*0.20f;
                nextLook=now+1800;
            }
        }
        else if(expression==HmbEyeExpression::Relaxed){
            if(now>=nextLook){
                tx=(float)randomSigned(-(int)(LOOK_X_MAX*0.22f),(int)(LOOK_X_MAX*0.22f));
                ty=(float)randomSigned(-(int)(LOOK_Y_MAX*0.12f),(int)(LOOK_Y_MAX*0.18f));
                nextLook=now+1300;
            }
        }
        else if(expression==HmbEyeExpression::Happy){
            if(now>=nextLook){
                tx=(float)randomSigned(-(int)(LOOK_X_MAX*0.45f),(int)(LOOK_X_MAX*0.45f));
                ty=(float)randomSigned(-(int)(LOOK_Y_MAX*0.25f),(int)(LOOK_Y_MAX*0.25f));
                nextLook=now+750;
            }
        }
        else if(s==kDeviceStateListening){
            tx=0.0f;
            ty=0.0f;
        }
        else if(s==kDeviceStateConnecting || s==kDeviceStateWifiConfiguring){
            if(now>=nextLook){
                int lookX=(int)LOOK_X_MAX;
                int lookY=(int)(LOOK_Y_MAX*0.55f);
                tx=(float)randomSigned(-lookX,lookX);
                ty=(float)randomSigned(-lookY,lookY);
                nextLook=now+500;
            }
        }
        else if(s==kDeviceStateSpeaking){
            if(now>=nextLook){
                int lookX=(int)(LOOK_X_MAX*0.65f);
                int lookY=(int)(LOOK_Y_MAX*0.55f);
                tx=(float)randomSigned(-lookX,lookX);
                ty=(float)randomSigned(-lookY,lookY);
                nextLook=now+700;
            }
        }
        else if(now>=nextLook){
            int lookX=(int)LOOK_X_MAX;
            int lookY=(int)LOOK_Y_MAX;
            tx=(float)randomSigned(-lookX,lookX);
            ty=(float)randomSigned(-lookY,lookY);
            nextLook=now+800+(int64_t)(esp_random()%1800);
        }

        px+=(tx-px)*0.18f;
        py+=(ty-py)*0.18f;
        px=std::max(-LOOK_X_MAX,std::min(LOOK_X_MAX,px));
        py=std::max(-LOOK_Y_MAX,std::min(LOOK_Y_MAX,py));

        if(now>=nextBlink && !closing && blink<=0.0f){
            closing=true;
            int blinkBase=(expression==HmbEyeExpression::Sleepy) ? 1800 : 2500;
            int blinkRange=(expression==HmbEyeExpression::Sleepy) ? 1800 : 3500;
            nextBlink=now+blinkBase+(int64_t)(esp_random()%blinkRange);
        }
        if(closing){
            blink+=0.32f;
            if(blink>=1.0f){
                blink=1.0f;
                closing=false;
            }
        }
        else if(blink>0.0f){
            blink-=0.24f;
            if(blink<0.0f) blink=0.0f;
        }

        // Beide Augen erhalten dieselben Pupillenkoordinaten und denselben Blinkwert.
        // Nur die Lidform von Confused bleibt bewusst asymmetrisch.
        render(true,expression);
        push(devL);
        render(false,expression);
        push(devR);

        vTaskDelay(pdMS_TO_TICKS(45));
    }
}

// ============================================================================
// HmbDualEye
// ============================================================================
void HmbDualEye::Init(){
    ESP_LOGI(TAG,"Initializing HMBTEC DualEye / FlameEngine mode=%d",HMB_DISPLAY_MODE);
#if HMB_EYE_DISPLAY == HMB_EYE_GC9D01_160
    ESP_LOGI(TAG,"Display: GC9D01 160x160");
#elif HMB_EYE_DISPLAY == HMB_EYE_GC9A01_240
    ESP_LOGI(TAG,"Display: GC9A01 240x240");
#endif
    ESP_LOGI(TAG,"Framebuffer: %dx%d = %u bytes",W,H,(unsigned)(N*sizeof(uint16_t)));

    fb=(uint16_t*)heap_caps_malloc(N*sizeof(uint16_t),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!fb) fb=(uint16_t*)heap_caps_malloc(N*sizeof(uint16_t),MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
    if(!fb){
        ESP_LOGE(TAG,"Could not allocate DualEye framebuffer: %u bytes",(unsigned)(N*sizeof(uint16_t)));
        return;
    }
    std::memset(fb,0,N*sizeof(uint16_t));

    gpio_config_t g={};
    g.pin_bit_mask=(1ULL<<HMB_EYE_DC)|(1ULL<<HMB_EYE_RST_LEFT)|(1ULL<<HMB_EYE_RST_RIGHT);
    g.mode=GPIO_MODE_OUTPUT;
    ESP_ERROR_CHECK(gpio_config(&g));

    gpio_set_level(HMB_EYE_RST_LEFT,0);
    gpio_set_level(HMB_EYE_RST_RIGHT,0);
    vTaskDelay(pdMS_TO_TICKS(30));
    gpio_set_level(HMB_EYE_RST_LEFT,1);
    gpio_set_level(HMB_EYE_RST_RIGHT,1);
    vTaskDelay(pdMS_TO_TICKS(150));

    spi_bus_config_t bus={};
    bus.mosi_io_num=HMB_EYE_MOSI;
    bus.miso_io_num=-1;
    bus.sclk_io_num=HMB_EYE_SCLK;
    bus.quadwp_io_num=-1;
    bus.quadhd_io_num=-1;
    bus.max_transfer_sz=W*2;
    ESP_ERROR_CHECK(spi_bus_initialize(SPI2_HOST,&bus,SPI_DMA_CH_AUTO));

    spi_device_interface_config_t di={};
    di.clock_speed_hz=20000000;
    di.mode=0;
    di.spics_io_num=HMB_EYE_CS_LEFT;
    di.queue_size=1;
    ESP_ERROR_CHECK(spi_bus_add_device(SPI2_HOST,&di,&devL));

    di.spics_io_num=HMB_EYE_CS_RIGHT;
    ESP_ERROR_CHECK(spi_bus_add_device(SPI2_HOST,&di,&devR));

    // Die beiden physischen Displays sind um 180 Grad gegeneinander montiert.
    initPanel(devL,true);
    initPanel(devR,false);

    BaseType_t result=xTaskCreate(task,"hmb_eye",6144,nullptr,2,nullptr);
    if(result!=pdPASS){
        ESP_LOGE(TAG,"Could not create DualEye task");
        heap_caps_free(fb);
        fb=nullptr;
        return;
    }
    ESP_LOGI(TAG,"DualEye ready");
}
void HmbDualEye::SetState(DeviceState state){
    state_=state;
    eyeState=state;
}
bool HmbDualEye::SetExpression(const std::string& expression,int duration_ms){
    HmbEyeExpression e=HmbEyeExpression::Neutral;

    if(expression=="neutral") e=HmbEyeExpression::Neutral;
    else if(expression=="happy") e=HmbEyeExpression::Happy;
    else if(expression=="relaxed") e=HmbEyeExpression::Relaxed;
    else if(expression=="curious") e=HmbEyeExpression::Curious;
    else if(expression=="thinking") e=HmbEyeExpression::Thinking;
    else if(expression=="surprised") e=HmbEyeExpression::Surprised;
    else if(expression=="sad") e=HmbEyeExpression::Sad;
    else if(expression=="confused") e=HmbEyeExpression::Confused;
    else if(expression=="sleepy") e=HmbEyeExpression::Sleepy;
    else{
        ESP_LOGW(TAG,"Unknown expression: %s",expression.c_str());
        return false;
    }

    duration_ms=std::max(500,std::min(15000,duration_ms));
    eyeExpression=e;

    if(e==HmbEyeExpression::Neutral){
        expressionUntil=0;
    }
    else{
        expressionUntil=esp_timer_get_time()/1000+duration_ms;
    }

    ESP_LOGI(TAG,"Expression: %s, duration=%d ms",expressionName(e),duration_ms);
    return true;
}
void HmbDualEye::ClearExpression(){
    eyeExpression=HmbEyeExpression::Neutral;
    expressionUntil=0;
    ESP_LOGI(TAG,"Expression cleared -> neutral");
}
bool HmbDualEye::SetLook(const std::string& direction,int duration_ms){
    HmbEyeLook look=HmbEyeLook::Auto;

    if(direction=="auto") look=HmbEyeLook::Auto;
    else if(direction=="center") look=HmbEyeLook::Center;
    else if(direction=="left") look=HmbEyeLook::Left;
    else if(direction=="right") look=HmbEyeLook::Right;
    else if(direction=="up") look=HmbEyeLook::Up;
    else if(direction=="down") look=HmbEyeLook::Down;
    else if(direction=="up_left") look=HmbEyeLook::UpLeft;
    else if(direction=="up_right") look=HmbEyeLook::UpRight;
    else if(direction=="down_left") look=HmbEyeLook::DownLeft;
    else if(direction=="down_right") look=HmbEyeLook::DownRight;
    else{
        ESP_LOGW(TAG,"Unknown look direction: %s",direction.c_str());
        return false;
    }

    duration_ms=std::max(500,std::min(15000,duration_ms));
    eyeLook=look;

    if(look==HmbEyeLook::Auto){
        lookUntil=0;
    }
    else{
        lookUntil=esp_timer_get_time()/1000+duration_ms;
        applyLookTarget(look);
    }

    ESP_LOGI(TAG,"Look: %s, duration=%d ms",lookName(look),duration_ms);
    return true;
}
void HmbDualEye::ClearLook(){
    eyeLook=HmbEyeLook::Auto;
    lookUntil=0;
    ESP_LOGI(TAG,"Look cleared -> auto");
}

#else

void HmbDualEye::Init(){
}
void HmbDualEye::SetState(DeviceState state){
    state_=state;
}
bool HmbDualEye::SetExpression(const std::string&,int){
    return false;
}
void HmbDualEye::ClearExpression(){
}
bool HmbDualEye::SetLook(const std::string&,int){
    return false;
}
void HmbDualEye::ClearLook(){
}

#endif