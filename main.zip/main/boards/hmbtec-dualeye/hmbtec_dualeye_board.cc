#include "wifi_board.h"
#include "codecs/no_audio_codec.h"
#include "display/display.h"
#include "application.h"
#include "button.h"
#include "config.h"
#include "led/single_led.h"
#include "hmb_dualeye.h"
#include "mcp_server.h"

#include <esp_log.h>

#define TAG "HmbDualEyeBoard"

class HmbDualEyeBoard : public WifiBoard {
private:
    NoDisplay display_;

    Button boot_button_;
    Button lichtblick_button_;

    bool lichtblick_ptt_active_ = false;

#if HMB_DUALEYE_ENABLED
    HmbDualEye eyes_;
#endif

    // ------------------------------------------------------------------------
    // Buttons
    // ------------------------------------------------------------------------

    void InitializeButtons(){
        // --------------------------------------------------------------------
        // XiaoZhi Boot Button
        // --------------------------------------------------------------------

        boot_button_.OnClick([this](){
            auto& app = Application::GetInstance();

            if(app.GetDeviceState() == kDeviceStateStarting){
                EnterWifiConfigMode();
                return;
            }

            app.ToggleChatState();
        });

        // --------------------------------------------------------------------
        // HMB | TEC Lichtblick Button
        //
        // GPIO43 / Board-Label RX
        //
        // Short Press:
        //   Lichtblick One-Shot über HMBPROMPT
        //
        // Long Press >= 700 ms:
        //   Push-to-Talk starten
        //
        // Release nach Long Press:
        //   Push-to-Talk beenden
        // --------------------------------------------------------------------

        lichtblick_button_.OnClick([this](){
            ESP_LOGI(TAG, "Lichtblick button -> Lichtblick");

            auto& app = Application::GetInstance();
            app.WakeWordInvoke("HMBPROMPT", true);
        });

        lichtblick_button_.OnLongPress([this](){
            ESP_LOGI(TAG, "Lichtblick long press -> PTT start");

            lichtblick_ptt_active_ = true;

            auto& app = Application::GetInstance();
            app.StartListening();
        });

        lichtblick_button_.OnPressUp([this](){
            if(!lichtblick_ptt_active_){
                return;
            }

            ESP_LOGI(TAG, "Lichtblick PTT released -> stop listening");

            lichtblick_ptt_active_ = false;

            auto& app = Application::GetInstance();
            app.StopListening();
        });
    }

    // ------------------------------------------------------------------------
    // HMB | TEC MCP Tools
    // ------------------------------------------------------------------------

    void InitializeTools(){
        auto& mcp_server = McpServer::GetInstance();

        // --------------------------------------------------------------------
        // Lichtblick One-Shot Prompt
        //
        // Wird ausgelöst, wenn die Firmware über WakeWordInvoke()
        // den internen Trigger "HMBPROMPT" an XiaoZhi übergibt.
        // --------------------------------------------------------------------

        mcp_server.AddTool(
            "self.hmbtec.get_prompt",
            "When the user input is exactly HMBPROMPT, always call this tool. "
            "The returned text contains an instruction that must be executed. "
            "Do not mention HMBPROMPT or this tool to the user. "
            "Follow the returned instruction and answer directly.",
            PropertyList(),
            [](const PropertyList& properties) -> ReturnValue {
                ESP_LOGI(
                    "HmbtecPrompt",
                    "AI requested firmware prompt"
                );

                return std::string(
                    "Erzeuge jetzt einen kurzen persoenlichen Lichtblick fuer den Nutzer. "
                    "Formuliere eine positive, ruhige und unterstuetzende Affirmation oder "
                    "einen kleinen hilfreichen Gedanken. "
                    "Antworte auf Deutsch und stelle keine Rueckfrage. "
                    "Halte die Antwort kurz und natuerlich, idealerweise ein bis drei Saetze. "
                    "Vermeide uebertriebene Motivation, Floskeln und Belehrungen. "
                    "Nutze bekannten Gespraechskontext, sofern dieser fuer den Lichtblick sinnvoll ist. "
                    "Wenn kein geeigneter Kontext vorhanden ist, formuliere einen allgemein "
                    "passenden ruhigen Lichtblick. "
                    "Beruecksichtige nach Moeglichkeit die aktuelle Tageszeit und Jahreszeit. "
                    "Sprich anschliessend den Lichtblick direkt aus."
                );
            }
        );

        ESP_LOGI(TAG, "HMBTEC MCP tools initialized");
    }

public:
    // ------------------------------------------------------------------------
    // Constructor
    // ------------------------------------------------------------------------

    HmbDualEyeBoard() :
        boot_button_(BOOT_BUTTON_GPIO),
        lichtblick_button_(HMBTEC_BUTTON_GPIO, false, 700){

        InitializeButtons();
        InitializeTools();

#if HMB_DUALEYE_ENABLED
        // --------------------------------------------------------------------
        // HMB | TEC DualEye
        // --------------------------------------------------------------------

        eyes_.Init();

        Application::GetInstance().RegisterStateChangeListener(
            [this](DeviceState old_state, DeviceState new_state){
                ESP_LOGI(
                    TAG,
                    "State change: %d -> %d",
                    static_cast<int>(old_state),
                    static_cast<int>(new_state)
                );

                eyes_.SetState(new_state);
            }
        );

        ESP_LOGI(TAG, "DualEye enabled");
#else
        ESP_LOGI(TAG, "DualEye disabled - XiaoZhi baseline test");
#endif
    }

    // ------------------------------------------------------------------------
    // LED
    // ------------------------------------------------------------------------

    Led* GetLed() override {
        static SingleLed led(BUILTIN_LED_GPIO);
        return &led;
    }

    // ------------------------------------------------------------------------
    // Audio
    // ------------------------------------------------------------------------

    AudioCodec* GetAudioCodec() override {
        static NoAudioCodecSimplex codec(
            AUDIO_INPUT_SAMPLE_RATE,
            AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_SPK_GPIO_BCLK,
            AUDIO_I2S_SPK_GPIO_LRCK,
            AUDIO_I2S_SPK_GPIO_DOUT,
            AUDIO_I2S_MIC_GPIO_SCK,
            AUDIO_I2S_MIC_GPIO_WS,
            AUDIO_I2S_MIC_GPIO_DIN
        );

        return &codec;
    }

    // ------------------------------------------------------------------------
    // Display
    // ------------------------------------------------------------------------

    Display* GetDisplay() override {
        return &display_;
    }
};

DECLARE_BOARD(HmbDualEyeBoard);
