#include "display/lv_display.h"
#include "misc/lv_event.h"
#include "wifi_board.h"
#include "sensecap_audio_codec.h"
#include "display/lcd_display.h"
#include "application.h"
#include "knob.h"
#include "config.h"
#include "led/single_led.h"
#include "power_save_timer.h"
#include "sscma_camera.h"
#include "persona_version.h"
extern "C" void HmbPersonaRequestFinish();
#include "mcp_server.h"
#include "lvgl_theme.h"

#include <esp_log.h>
#include <esp_check.h>
#include <esp_lcd_panel_io.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_spd2010.h>
#include <esp_adc/adc_oneshot.h>
#include <driver/spi_master.h>
#include <driver/i2c_master.h>
#include <driver/spi_common.h>
#include <iot_button.h>
#include <iot_knob.h>
#include <esp_io_expander_tca95xx_16bit.h>
#include <esp_sleep.h>
#include <esp_console.h>
#include <esp_mac.h>
#include <nvs_flash.h>
#include <esp_app_desc.h>

#include "assets/lang_config.h"
#include "led_strip.h"
#include "freertos/task.h"
#include <atomic>
#include <cstdio>
#include <string>
#include <cJSON.h>
#include <esp_timer.h>
#include <esp_wifi.h>
#include <lwip/sockets.h>
#include <lwip/inet.h>
#include <cerrno>
#include <cstring>

#define TAG "sensecap_watcher"

// HMB Persona V0.3.24: Kamera-Callback schreibt nur atomare Messwerte.
// LVGL wird ausschliesslich durch den LVGL-Timer aktualisiert.
static std::atomic<int> hmb_persona_stage{0};
static std::atomic<int> hmb_persona_error{0};
static std::atomic<int> hmb_persona_present{0};
static std::atomic<int> hmb_persona_score{0};
static std::atomic<int64_t> hmb_persona_last_us{0};
static std::atomic<int> hmb_light_error{0}; // 1=URL/token,2=connect,3=upload/HTTP,4=other,5=JSON format,6=capture
static std::atomic<int> hmb_light_status{0}; // 0=idle,1=capture,2=analyze,3=ok,4=error
static std::atomic<uint32_t> hmb_persona_finish_request{0}; // MCP scene received
static std::atomic<int> hmb_light_r{0}, hmb_light_g{0}, hmb_light_b{0};
static std::atomic<int> hmb_light_brightness{0}, hmb_light_dynamics{0};

// HMB|TEC Persona Art-Net V0.3.25 – Konfiguration
// Universe 0 (Art-Net Port-Address 0); UDP Broadcast 255.255.255.255:6454
#define HMB_ARTNET_UNIVERSE       0
#define HMB_ARTNET_FPS            20
#define HMB_ARTNET_DMX_START      1  // DMX-Kanal 1 = Arrayindex 0
#define HMB_ARTNET_BROADCAST_IP   "255.255.255.255"
#define HMB_ARTNET_DMX_LENGTH     512
#define HMB_ARTNET_TEST_HOLD_MS    350  // je Kanal 350 ms
#define HMB_ARTNET_TEST_ZERO_MS    500  // Nullrahmen vor/nach Test
static std::atomic<int> hmb_light_transition{2000};
static std::atomic<bool> hmb_artnet_scene_ready{false};
static std::atomic<uint32_t> hmb_artnet_packets{0};
static std::atomic<int> hmb_artnet_last_error{0};

// Kontinuierlicher ArtDMX-Stream: Empfaenger-Fail-Safe bleibt versorgt.
// Mapping: CH1=R, CH2=G, CH3=B, CH4=Brightness, CH5=Dynamics (0..100),
// CH6=Transition in 100ms-Schritten (0..255).
static void HmbArtNetTask(void*) {
    int sock = -1;
    uint8_t sequence = 1;
    uint32_t last_log = 0;
    int startup_phase = 0; // 0=Blackout, 1..6=Einzelkanal, 7=Blackout, 8=Normalbetrieb
    int64_t phase_since_us = 0;
    bool wifi_was_connected = false;
    uint8_t packet[18 + HMB_ARTNET_DMX_LENGTH] = {};
    memcpy(packet, "Art-Net", 7);
    packet[7] = 0;
    packet[8] = 0x00; packet[9] = 0x50;  // ArtDMX opcode, little endian
    packet[10] = 0; packet[11] = 14;    // Protocol version, big endian
    packet[13] = 0;                    // Physical
    packet[14] = HMB_ARTNET_UNIVERSE & 0xFF;
    packet[15] = (HMB_ARTNET_UNIVERSE >> 8) & 0x7F;
    packet[16] = HMB_ARTNET_DMX_LENGTH >> 8;
    packet[17] = HMB_ARTNET_DMX_LENGTH & 0xFF;
    struct sockaddr_in dst = {};
    dst.sin_family = AF_INET;
    dst.sin_port = htons(6454);
    dst.sin_addr.s_addr = inet_addr(HMB_ARTNET_BROADCAST_IP);
    for (;;) {
        wifi_ap_record_t ap = {};
        if (esp_wifi_sta_get_ap_info(&ap) != ESP_OK) {
            if (sock >= 0) { close(sock); sock = -1; }
            wifi_was_connected = false;
            vTaskDelay(pdMS_TO_TICKS(500));
            continue;
        }
        if (!wifi_was_connected) {
            wifi_was_connected = true;
            startup_phase = 0;
            phase_since_us = esp_timer_get_time();
            ESP_LOGI(TAG, "PERSONA ARTNET: WLAN bereit; starte DMX-Nullsetzung und CH1..6-Test");
        }
        if (sock < 0) {
            sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
            if (sock < 0) {
                hmb_artnet_last_error.store(errno);
                vTaskDelay(pdMS_TO_TICKS(1000));
                continue;
            }
            int enabled = 1;
            if (setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &enabled, sizeof(enabled)) < 0) {
                hmb_artnet_last_error.store(errno);
                close(sock); sock = -1;
                vTaskDelay(pdMS_TO_TICKS(1000));
                continue;
            }
        }
        memset(packet + 18, 0, HMB_ARTNET_DMX_LENGTH);
        const int start = HMB_ARTNET_DMX_START - 1;
        const int64_t now_us = esp_timer_get_time();
        if (startup_phase < 8) {
            const int64_t hold_us = (startup_phase == 0 || startup_phase == 7)
                ? HMB_ARTNET_TEST_ZERO_MS * 1000LL : HMB_ARTNET_TEST_HOLD_MS * 1000LL;
            if (now_us - phase_since_us >= hold_us) {
                ++startup_phase;
                phase_since_us = now_us;
                if (startup_phase <= 6) {
                    ESP_LOGI(TAG, "PERSONA ARTNET TEST: CH%d = 255 (alle anderen = 0)", startup_phase);
                } else if (startup_phase == 7) {
                    ESP_LOGI(TAG, "PERSONA ARTNET TEST: alle 512 DMX-Kanaele = 0");
                } else {
                    ESP_LOGI(TAG, "PERSONA ARTNET TEST: abgeschlossen, Normalbetrieb");
                }
            }
            if (startup_phase >= 1 && startup_phase <= 6 &&
                start >= 0 && start + startup_phase - 1 < HMB_ARTNET_DMX_LENGTH) {
                packet[18 + start + startup_phase - 1] = 255;
            }
        } else if (hmb_artnet_scene_ready.load(std::memory_order_acquire) &&
                   start >= 0 && start + 5 < HMB_ARTNET_DMX_LENGTH) {
            packet[18 + start + 0] = static_cast<uint8_t>(hmb_light_r.load());
            packet[18 + start + 1] = static_cast<uint8_t>(hmb_light_g.load());
            packet[18 + start + 2] = static_cast<uint8_t>(hmb_light_b.load());
            packet[18 + start + 3] = static_cast<uint8_t>(hmb_light_brightness.load());
            packet[18 + start + 4] = static_cast<uint8_t>(hmb_light_dynamics.load());
            int transition_units = hmb_light_transition.load() / 100;
            if (transition_units > 255) transition_units = 255;
            packet[18 + start + 5] = static_cast<uint8_t>(transition_units);
        }
        packet[12] = sequence++;
        if (sequence == 0) sequence = 1;
        const int sent = sendto(sock, packet, sizeof(packet), 0,
                                reinterpret_cast<const sockaddr*>(&dst), sizeof(dst));
        if (sent != sizeof(packet)) {
            hmb_artnet_last_error.store(errno);
            ESP_LOGW(TAG, "PERSONA ARTNET: sendto failed errno=%d", errno);
            close(sock); sock = -1;
            vTaskDelay(pdMS_TO_TICKS(500));
            continue;
        }
        hmb_artnet_packets.fetch_add(1);
        const uint32_t count = hmb_artnet_packets.load();
        if (count - last_log >= HMB_ARTNET_FPS * 10) {
            last_log = count;
            ESP_LOGI(TAG, "PERSONA ARTNET: universe=%d broadcast=%s packets=%lu RGB=%d,%d,%d",
                     HMB_ARTNET_UNIVERSE, HMB_ARTNET_BROADCAST_IP,
                     (unsigned long)count, hmb_light_r.load(), hmb_light_g.load(), hmb_light_b.load());
        }
        vTaskDelay(pdMS_TO_TICKS(1000 / HMB_ARTNET_FPS));
    }
}



extern "C" void HmbPersonaInferenceStatus(int stage, int error) {
    hmb_persona_error.store(error, std::memory_order_relaxed);
    hmb_persona_stage.store(stage, std::memory_order_release);
}

extern "C" void HmbPersonaCameraUpdate(int present, int score) {
    hmb_persona_stage.store(3, std::memory_order_release);
    hmb_persona_present.store(present, std::memory_order_relaxed);
    hmb_persona_score.store(score, std::memory_order_relaxed);
    hmb_persona_last_us.store(esp_timer_get_time(), std::memory_order_release);
}


class CustomLcdDisplay : public SpiLcdDisplay {
    private:
        lv_obj_t* persona_label_ = nullptr;

    public:
        CustomLcdDisplay(esp_lcd_panel_io_handle_t io_handle, 
                        esp_lcd_panel_handle_t panel_handle,
                        int width,
                        int height,
                        int offset_x,
                        int offset_y,
                        bool mirror_x,
                        bool mirror_y,
                        bool swap_xy) 
            : SpiLcdDisplay(io_handle, panel_handle, width, height, offset_x, offset_y, mirror_x, mirror_y, swap_xy) {
            // Note: UI customization should be done in SetupUI(), not in constructor
            // to ensure lvgl objects are created before accessing them
        }

        virtual void SetupUI() override {
            // Call parent SetupUI() first to create all lvgl objects
            SpiLcdDisplay::SetupUI();

            DisplayLockGuard lock(this);
            auto lvgl_theme = static_cast<LvglTheme*>(current_theme_);
            auto text_font = lvgl_theme->text_font()->font();
            auto icon_font = lvgl_theme->icon_font()->font();

            lv_obj_set_size(top_bar_, LV_HOR_RES, text_font->line_height);
            lv_obj_set_style_layout(top_bar_, LV_LAYOUT_NONE, 0);
            lv_obj_set_style_pad_top(top_bar_, 10, 0);
            lv_obj_set_style_pad_bottom(top_bar_, 1, 0);

            lv_obj_set_size(status_bar_, LV_HOR_RES, text_font->line_height);
            lv_obj_set_style_layout(status_bar_, LV_LAYOUT_NONE, 0);
            lv_obj_set_style_pad_top(status_bar_, 10, 0);
            lv_obj_set_style_pad_bottom(status_bar_, 1, 0);
            lv_obj_set_y(status_bar_, text_font->line_height);
            lv_obj_add_flag(status_bar_, LV_OBJ_FLAG_IGNORE_LAYOUT);

            // Reparent mute and battery labels to top_bar_ to allow absolute positioning
            lv_obj_set_parent(mute_label_, top_bar_);
            lv_obj_set_parent(battery_label_, top_bar_);
            lv_obj_set_style_margin_left(battery_label_, 0, 0);

            // 针对圆形屏幕调整位置
            //      network  mute  battery     //
            //               status            //
            lv_obj_align(network_label_, LV_ALIGN_TOP_MID, -1.5 * icon_font->line_height, 0);
            lv_obj_align(mute_label_, LV_ALIGN_TOP_MID, 1.0 * icon_font->line_height, 0);
            lv_obj_align(battery_label_, LV_ALIGN_TOP_MID, 2.5 * icon_font->line_height, 0);
            
            lv_obj_align(status_label_, LV_ALIGN_BOTTOM_MID, 0, 0);
            lv_obj_set_flex_grow(status_label_, 0);
            lv_obj_set_width(status_label_, LV_HOR_RES * 0.75);
            lv_label_set_long_mode(status_label_, LV_LABEL_LONG_SCROLL_CIRCULAR);

            lv_obj_align(notification_label_, LV_ALIGN_BOTTOM_MID, 0, 0);
            lv_obj_set_width(notification_label_, LV_HOR_RES * 0.75);
            lv_label_set_long_mode(notification_label_, LV_LABEL_LONG_SCROLL_CIRCULAR);

            lv_obj_align(low_battery_popup_, LV_ALIGN_BOTTOM_MID, 0, -20);
            lv_obj_set_style_bg_color(low_battery_popup_, lv_color_hex(0xFF0000), 0);
            lv_obj_set_width(low_battery_label_, LV_HOR_RES * 0.75);
            lv_label_set_long_mode(low_battery_label_, LV_LABEL_LONG_SCROLL_CIRCULAR);

            // 针对圆形屏幕调整底部对话框位置，避免被圆角遮挡
            lv_obj_set_style_pad_bottom(bottom_bar_, 30, 0);
            lv_obj_set_width(chat_message_label_, LV_HOR_RES * 0.75); // 限制宽度，避免文字贴边
            // Persona Light: keine KI-Laufschrift auf dem Display.
            lv_obj_add_flag(chat_message_label_, LV_OBJ_FLAG_HIDDEN);


            // HMB_PERSONA_V0318: Live-Anzeige statt Versionsmeldung.
            // Die erprobte Position und schwarze Schrift bleiben erhalten.
            lv_obj_t* persona_screen = lv_obj_get_screen(bottom_bar_);
            persona_label_ = lv_label_create(persona_screen);
            lv_obj_set_width(persona_label_, lv_display_get_horizontal_resolution(nullptr) * 60 / 100);
            lv_label_set_long_mode(persona_label_, LV_LABEL_LONG_WRAP);
            lv_obj_set_style_text_align(persona_label_, LV_TEXT_ALIGN_CENTER, 0);
            lv_obj_set_style_text_color(persona_label_, lv_color_hex(0x000000), 0);
            lv_obj_set_style_bg_opa(persona_label_, LV_OPA_TRANSP, 0);
            lv_obj_set_style_pad_all(persona_label_, 0, 0);
            lv_label_set_text(persona_label_, "PERSONA LIGHT " HMB_PERSONA_VERSION "\nKAMERA: WARTE...");
            lv_obj_align(persona_label_, LV_ALIGN_CENTER, 0,
                         lv_display_get_vertical_resolution(nullptr) * 15 / 100);
            lv_obj_move_foreground(persona_label_);

            lv_timer_create([](lv_timer_t* timer) {
                lv_obj_t* label = static_cast<lv_obj_t*>(lv_timer_get_user_data(timer));
                if (!label) return;
            const int64_t last = hmb_persona_last_us.load(std::memory_order_acquire);
                const bool fresh = last != 0 && (esp_timer_get_time() - last) < 10000000LL;
                char message[160];
                const int light_status = hmb_light_status.load();
                if (!fresh) {
                    const int stage = hmb_persona_stage.load(std::memory_order_acquire);
                    const int error = hmb_persona_error.load(std::memory_order_relaxed);
                    // Fehlende Inferenz-Frames waehrend der KI-Kommunikation sind
                    // erwartbar: Inferenz ist nur im Idle-Zustand aktiv.
                    const bool inference_paused =
                        Application::GetInstance().GetDeviceState() != kDeviceStateIdle;
                    const char* detail = stage == 0 ? "INIT" : stage == 1 ? "STARTET" :
                        stage == 2 ? "LAEUFT / KEIN FRAME" :
                        stage == 3 ? (inference_paused ? "ERKENNUNG PAUSIERT" : "KEIN NEUER FRAME") :
                        stage == 4 ? "GESTOPPT" : "STARTFEHLER";
                    snprintf(message, sizeof(message), "PERSONA LIGHT " HMB_PERSONA_VERSION "\n%s (%d)", detail, error);
                } else if (hmb_persona_present.load(std::memory_order_relaxed)) {
                    snprintf(message, sizeof(message), "PERSONA LIGHT " HMB_PERSONA_VERSION "\nPERSON ERKANNT\nSCORE: %d",
                             hmb_persona_score.load(std::memory_order_relaxed));
                } else {
                    snprintf(message, sizeof(message), "PERSONA LIGHT " HMB_PERSONA_VERSION "\nKEINE PERSON");
                }
                if (light_status == 1 || light_status == 2) {
                    snprintf(message, sizeof(message), "PERSONA LIGHT " HMB_PERSONA_VERSION "\n%s",
                             light_status == 1 ? "FOTO..." : "MCP KI ANFRAGE...");
                } else if (light_status == 3) {
                    snprintf(message, sizeof(message), "PERSONA LIGHT " HMB_PERSONA_VERSION
                             "\nRGB %d/%d/%d\nHELL %d DYN %d",
                             hmb_light_r.load(), hmb_light_g.load(), hmb_light_b.load(),
                             hmb_light_brightness.load(), hmb_light_dynamics.load());
                } else if (light_status == 4) {
                    snprintf(message, sizeof(message), "PERSONA LIGHT " HMB_PERSONA_VERSION "\nANALYSEFEHLER %d", hmb_light_error.load());
                }
                lv_label_set_text(label, message);
            }, 500, persona_label_);

        }
};

class SensecapWatcher : public WifiBoard {
private:
    i2c_master_bus_handle_t i2c_bus_;
    LcdDisplay* display_;
    std::unique_ptr<Knob> knob_;
    esp_io_expander_handle_t io_exp_handle;
    button_handle_t btns;
    PowerSaveTimer* power_save_timer_;
    esp_lcd_panel_io_handle_t panel_io_ = nullptr;
    esp_lcd_panel_handle_t panel_ = nullptr;
    uint32_t long_press_cnt_;
    button_driver_t* btn_driver_ = nullptr;
    static SensecapWatcher* instance_;
    SscmaCamera* camera_ = nullptr;

    void InitializePowerSaveTimer() {
        power_save_timer_ = new PowerSaveTimer(-1, 60, 300);
        power_save_timer_->OnEnterSleepMode([this]() {
            GetDisplay()->SetPowerSaveMode(true);
            GetBacklight()->SetBrightness(10);
        });
        power_save_timer_->OnExitSleepMode([this]() {
            GetDisplay()->SetPowerSaveMode(false);
            GetBacklight()->RestoreBrightness();
        });
        power_save_timer_->OnShutdownRequest([this]() {
            ESP_LOGI(TAG, "Shutting down");
            bool is_charging = (IoExpanderGetLevel(BSP_PWR_VBUS_IN_DET) == 0);
            if (is_charging) {
                ESP_LOGI(TAG, "charging");
                // Serialize with battery polling on the main task. USB may have
                // disconnected by the time the request is handled.
                Application::GetInstance().Schedule([this]() {
                    power_save_timer_->SetEnabled(false);
                    if (IoExpanderGetLevel(BSP_PWR_VBUS_IN_DET) == 0) {
                        GetBacklight()->SetBrightness(0);
                    } else {
                        power_save_timer_->SetEnabled(true);
                    }
                });
            } else {
                IoExpanderSetLevel(BSP_PWR_SYSTEM, 0);
            }
        });
        power_save_timer_->SetEnabled(true);
    }

    void InitializeI2c() {
        // Initialize I2C peripheral
        i2c_master_bus_config_t i2c_bus_cfg = {
            .i2c_port = (i2c_port_t)0,
            .sda_io_num = BSP_GENERAL_I2C_SDA,
            .scl_io_num = BSP_GENERAL_I2C_SCL,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags = {
                .enable_internal_pullup = 1,
            },
        };
        ESP_ERROR_CHECK(i2c_new_master_bus(&i2c_bus_cfg, &i2c_bus_));

        // pulldown for lcd i2c
        const gpio_config_t io_config = {
            .pin_bit_mask = (1ULL << BSP_TOUCH_I2C_SDA) | (1ULL << BSP_TOUCH_I2C_SCL) | (1ULL << BSP_SPI3_HOST_PCLK) | (1ULL << BSP_SPI3_HOST_DATA0) | (1ULL << BSP_SPI3_HOST_DATA1)
                            | (1ULL << BSP_SPI3_HOST_DATA2) | (1ULL << BSP_SPI3_HOST_DATA3) | (1ULL << BSP_LCD_SPI_CS) | (1UL << DISPLAY_BACKLIGHT_PIN),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE,
        };
        gpio_config(&io_config);

        gpio_set_level(BSP_TOUCH_I2C_SDA, 0);
        gpio_set_level(BSP_TOUCH_I2C_SCL, 0);
    
        gpio_set_level(BSP_LCD_SPI_CS, 0);
        gpio_set_level(DISPLAY_BACKLIGHT_PIN, 0);
        gpio_set_level(BSP_SPI3_HOST_PCLK, 0);
        gpio_set_level(BSP_SPI3_HOST_DATA0, 0);
        gpio_set_level(BSP_SPI3_HOST_DATA1, 0);
        gpio_set_level(BSP_SPI3_HOST_DATA2, 0);
        gpio_set_level(BSP_SPI3_HOST_DATA3, 0);

    }

    esp_err_t IoExpanderSetLevel(uint16_t pin_mask, uint8_t level) {
        return esp_io_expander_set_level(io_exp_handle, pin_mask, level);
    }

    uint8_t IoExpanderGetLevel(uint16_t pin_mask) {
        uint32_t pin_val = 0;
        esp_io_expander_get_level(io_exp_handle, DRV_IO_EXP_INPUT_MASK, &pin_val);
        pin_mask &= DRV_IO_EXP_INPUT_MASK;
        return (uint8_t)((pin_val & pin_mask) ? 1 : 0);
    }

    void InitializeExpander() {
        esp_err_t ret = ESP_OK;
        esp_io_expander_new_i2c_tca95xx_16bit(i2c_bus_, ESP_IO_EXPANDER_I2C_TCA9555_ADDRESS_001, &io_exp_handle);

        ret |= esp_io_expander_set_dir(io_exp_handle, DRV_IO_EXP_INPUT_MASK, IO_EXPANDER_INPUT);
        ret |= esp_io_expander_set_dir(io_exp_handle, DRV_IO_EXP_OUTPUT_MASK, IO_EXPANDER_OUTPUT);
        ret |= esp_io_expander_set_level(io_exp_handle, DRV_IO_EXP_OUTPUT_MASK, 0);
        ret |= esp_io_expander_set_level(io_exp_handle, BSP_PWR_SYSTEM, 1);
        vTaskDelay(100 / portTICK_PERIOD_MS);
        ret |= esp_io_expander_set_level(io_exp_handle, BSP_PWR_START_UP, 1);
        vTaskDelay(50 / portTICK_PERIOD_MS);
    
        uint32_t pin_val = 0;
        ret |= esp_io_expander_get_level(io_exp_handle, DRV_IO_EXP_INPUT_MASK, &pin_val);
        ESP_LOGI(TAG, "IO expander initialized: %x", DRV_IO_EXP_OUTPUT_MASK | (uint16_t)pin_val);
    
        assert(ret == ESP_OK);
    }

    void OnKnobRotate(bool clockwise) {
        auto codec = GetAudioCodec();
        int current_volume = codec->output_volume();
        int new_volume = current_volume + (clockwise ? -5 : 5); 

        // 确保音量在有效范围内
        if (new_volume > 100) {
            new_volume = 100;
            ESP_LOGW(TAG, "Volume reached maximum limit: %d", new_volume);
        } else if (new_volume < 0) {
            new_volume = 0;
            ESP_LOGW(TAG, "Volume reached minimum limit: %d", new_volume);
        }

        codec->SetOutputVolume(new_volume);
        ESP_LOGI(TAG, "Volume changed from %d to %d", current_volume, new_volume);
        
        // 显示通知前检查实际变化
        if (new_volume != codec->output_volume()) {
            ESP_LOGE(TAG, "Failed to set volume! Expected:%d Actual:%d", 
                   new_volume, codec->output_volume());
        }
        GetDisplay()->ShowNotification(std::string(Lang::Strings::VOLUME) + ": "+std::to_string(codec->output_volume()));
        power_save_timer_->WakeUp();
    }

    void InitializeKnob() {
        knob_ = std::make_unique<Knob>(BSP_KNOB_A_PIN, BSP_KNOB_B_PIN);
        knob_->OnRotate([this](bool clockwise) {
            ESP_LOGD(TAG, "Knob rotation detected. Clockwise:%s", clockwise ? "true" : "false");
            OnKnobRotate(clockwise);
        });
        ESP_LOGI(TAG, "Knob initialized with pins A:%d B:%d", BSP_KNOB_A_PIN, BSP_KNOB_B_PIN);
    }

    void InitializeButton() {
        // 设置静态实例指针
        instance_ = this;
        
        // watcher 是通过长按滚轮进行开机的, 需要等待滚轮释放, 否则用户开机松手时可能会误触成单击
        ESP_LOGI(TAG, "waiting for knob button release");
        while(IoExpanderGetLevel(BSP_KNOB_BTN) == 0) {
            vTaskDelay(pdMS_TO_TICKS(50));
        }

        button_config_t btn_config = {
            .long_press_time = 2000,
            .short_press_time = 0
        };
        btn_driver_ = (button_driver_t*)calloc(1, sizeof(button_driver_t));
        btn_driver_->enable_power_save = false;
        btn_driver_->get_key_level = [](button_driver_t *button_driver) -> uint8_t {
            return !instance_->IoExpanderGetLevel(BSP_KNOB_BTN);
        };
        
        ESP_ERROR_CHECK(iot_button_create(&btn_config, btn_driver_, &btns));
        
        iot_button_register_cb(btns, BUTTON_SINGLE_CLICK, nullptr, [](void* button_handle, void* usr_data) {
            auto self = static_cast<SensecapWatcher*>(usr_data);
            self->power_save_timer_->WakeUp();

            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting) {
                self->EnterWifiConfigMode();
                return;
            }
            app.ToggleChatState();
        }, this);
        
        iot_button_register_cb(btns, BUTTON_LONG_PRESS_START, nullptr, [](void* button_handle, void* usr_data) {
            auto self = static_cast<SensecapWatcher*>(usr_data);
            bool is_charging = (self->IoExpanderGetLevel(BSP_PWR_VBUS_IN_DET) == 0);
            self->long_press_cnt_ = 0;
            if (is_charging) {
                ESP_LOGI(TAG, "charging");
            } else {
                self->IoExpanderSetLevel(BSP_PWR_LCD, 0);
                self->IoExpanderSetLevel(BSP_PWR_SYSTEM, 0);
            }
        }, this);

        iot_button_register_cb(btns, BUTTON_LONG_PRESS_HOLD, nullptr, [](void* button_handle, void* usr_data) {
            auto self = static_cast<SensecapWatcher*>(usr_data);
            self->long_press_cnt_++; // 每隔20ms加一
            // 长按10s 恢复出厂设置: 2+0.02*400 = 10
            if (self->long_press_cnt_ > 400) {
                ESP_LOGI(TAG, "Factory reset");
                nvs_flash_erase();
                esp_restart();
            }
        }, this);
    }

    void InitializeSpi() {
        ESP_LOGI(TAG, "Initialize SSCMA SPI bus");
        spi_bus_config_t spi_cfg = {0};

        spi_cfg.mosi_io_num = BSP_SPI2_HOST_MOSI;
        spi_cfg.miso_io_num = BSP_SPI2_HOST_MISO;
        spi_cfg.sclk_io_num = BSP_SPI2_HOST_SCLK;
        spi_cfg.quadwp_io_num = -1;
        spi_cfg.quadhd_io_num = -1;
        spi_cfg.isr_cpu_id = ESP_INTR_CPU_AFFINITY_1;
        spi_cfg.max_transfer_sz = 4095;
   
        ESP_ERROR_CHECK(spi_bus_initialize(SPI2_HOST, &spi_cfg, SPI_DMA_CH_AUTO));

        ESP_LOGI(TAG, "Initialize QSPI bus");

        spi_bus_config_t qspi_cfg = {0};
        qspi_cfg.sclk_io_num = BSP_SPI3_HOST_PCLK;
        qspi_cfg.data0_io_num = BSP_SPI3_HOST_DATA0;
        qspi_cfg.data1_io_num = BSP_SPI3_HOST_DATA1;
        qspi_cfg.data2_io_num = BSP_SPI3_HOST_DATA2;
        qspi_cfg.data3_io_num = BSP_SPI3_HOST_DATA3;
        qspi_cfg.max_transfer_sz = DISPLAY_WIDTH * DISPLAY_HEIGHT * DRV_LCD_BITS_PER_PIXEL / 8 / CONFIG_BSP_LCD_SPI_DMA_SIZE_DIV;
    
        ESP_ERROR_CHECK(spi_bus_initialize(SPI3_HOST, &qspi_cfg, SPI_DMA_CH_AUTO));
    }

    void Initializespd2010Display() {
        ESP_LOGI(TAG, "Install panel IO");
        const esp_lcd_panel_io_spi_config_t io_config = {
            .cs_gpio_num = BSP_LCD_SPI_CS,
            .dc_gpio_num = GPIO_NUM_NC,
            .spi_mode = 3,
            .pclk_hz = DRV_LCD_PIXEL_CLK_HZ,
            .trans_queue_depth = 2,
            .lcd_cmd_bits = DRV_LCD_CMD_BITS,
            .lcd_param_bits = DRV_LCD_PARAM_BITS,
            .flags = {
                .quad_mode = true,
            },
        };
        spd2010_vendor_config_t vendor_config = {
            .flags = {
                .use_qspi_interface = 1,
            },
        };
        esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)BSP_LCD_SPI_NUM, &io_config, &panel_io_);
    
        ESP_LOGD(TAG, "Install LCD driver");
        esp_lcd_panel_dev_config_t panel_config = {};
        panel_config.rgb_ele_order = DRV_LCD_RGB_ELEMENT_ORDER;
        panel_config.bits_per_pixel = DRV_LCD_BITS_PER_PIXEL;
        panel_config.reset_gpio_num = BSP_LCD_GPIO_RST; // Shared with Touch reset
        panel_config.vendor_config = &vendor_config;
        esp_lcd_new_panel_spd2010(panel_io_, &panel_config, &panel_);

        esp_lcd_panel_reset(panel_);
        esp_lcd_panel_init(panel_);
        esp_lcd_panel_mirror(panel_, DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y);
        esp_lcd_panel_disp_on_off(panel_, true);

        display_ = new CustomLcdDisplay(panel_io_, panel_,
            DISPLAY_WIDTH, DISPLAY_HEIGHT, DISPLAY_OFFSET_X, DISPLAY_OFFSET_Y, DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y, DISPLAY_SWAP_XY);
        
        // 使每次刷新的起始列数索引是4的倍数且列数总数是4的倍数，以满足SPD2010的要求
        lv_display_add_event_cb(lv_display_get_default(), [](lv_event_t *e) {
            lv_area_t *area = (lv_area_t *)lv_event_get_param(e);
            uint16_t x1 = area->x1;
            uint16_t x2 = area->x2;
            // round the start of area down to the nearest 4N number
            area->x1 = (x1 >> 2) << 2;
            // round the end of area up to the nearest 4M+3 number
            area->x2 = ((x2 >> 2) << 2) + 3;
        }, LV_EVENT_INVALIDATE_AREA, NULL);
        
    }

    uint16_t BatterygetVoltage(void) {
        static bool initialized = false;
        static adc_oneshot_unit_handle_t adc_handle;
        static adc_cali_handle_t cali_handle = NULL;
        if (!initialized) {
            adc_oneshot_unit_init_cfg_t init_config = {
                .unit_id = ADC_UNIT_1,
            };
            adc_oneshot_new_unit(&init_config, &adc_handle);
    
            adc_oneshot_chan_cfg_t ch_config = {
                .atten = BSP_BAT_ADC_ATTEN,
                .bitwidth = ADC_BITWIDTH_DEFAULT,
            };
            adc_oneshot_config_channel(adc_handle, BSP_BAT_ADC_CHAN, &ch_config);
    
            adc_cali_curve_fitting_config_t cali_config = {
                .unit_id = ADC_UNIT_1,
                .chan = BSP_BAT_ADC_CHAN,
                .atten = BSP_BAT_ADC_ATTEN,
                .bitwidth = ADC_BITWIDTH_DEFAULT,
            };
            if (adc_cali_create_scheme_curve_fitting(&cali_config, &cali_handle) == ESP_OK) {
                initialized = true;
            }
        }
        if (initialized) {
            int raw_value = 0;
            int voltage = 0; // mV
            adc_oneshot_read(adc_handle, BSP_BAT_ADC_CHAN, &raw_value);
            adc_cali_raw_to_voltage(cali_handle, raw_value, &voltage);
            voltage = voltage * 82 / 20;
            // ESP_LOGI(TAG, "voltage: %dmV", voltage);
            return (uint16_t)voltage;
        }
        return 0;
    }

    uint8_t BatterygetPercent(bool print = false) {
        int voltage = 0;
        for (uint8_t i = 0; i < 10; i++) {
            voltage += BatterygetVoltage();
        }
        voltage /= 10;
        int percent = (-1 * voltage * voltage + 9016 * voltage - 19189000) / 10000;
        percent = (percent > 100) ? 100 : (percent < 0) ? 0 : percent;
        if (print) {
            printf("voltage: %dmV, percentage: %d%%\r\n", voltage, percent);
        }
        return (uint8_t)percent;
    }

    void InitializeCmd() {
        esp_console_repl_t *repl = NULL;
        esp_console_repl_config_t repl_config = ESP_CONSOLE_REPL_CONFIG_DEFAULT();
        repl_config.max_cmdline_length = 1024;
        repl_config.prompt = "SenseCAP>";
        
        const esp_console_cmd_t cmd1 = {
            .command = "reboot",
            .help = "reboot the device",
            .hint = nullptr,
            .func = [](int argc, char** argv) -> int {
                esp_restart();
                return 0;
            },
            .argtable = nullptr
        };
        ESP_ERROR_CHECK(esp_console_cmd_register(&cmd1));

        const esp_console_cmd_t cmd2 = {
            .command = "shutdown",
            .help = "shutdown the device",
            .hint = nullptr,
            .func = NULL,
            .argtable = NULL,
            .func_w_context = [](void *context,int argc, char** argv) -> int {
                auto self = static_cast<SensecapWatcher*>(context);
                self->GetBacklight()->SetBrightness(0);
                self->IoExpanderSetLevel(BSP_PWR_SYSTEM, 0);
                return 0;
            },
            .context =this
        };
        ESP_ERROR_CHECK(esp_console_cmd_register(&cmd2));

        const esp_console_cmd_t cmd3 = {
            .command = "battery",
            .help = "get battery percent",
            .hint = NULL,
            .func = NULL,
            .argtable = NULL,
            .func_w_context = [](void *context,int argc, char** argv) -> int {
                auto self = static_cast<SensecapWatcher*>(context);
                self->BatterygetPercent(true);
                return 0;
            },
            .context =this
        };
        ESP_ERROR_CHECK(esp_console_cmd_register(&cmd3));

        const esp_console_cmd_t cmd4 = {
            .command = "factory_reset",
            .help = "factory reset and reboot the device",
            .hint = NULL,
            .func = NULL,
            .argtable = NULL,
            .func_w_context = [](void *context,int argc, char** argv) -> int {
                nvs_flash_erase();
                esp_restart();
                return 0;
            },
            .context =this
        };
        ESP_ERROR_CHECK(esp_console_cmd_register(&cmd4));

        const esp_console_cmd_t cmd5 = {
            .command = "read_mac",
            .help = "Read mac address",
            .hint = NULL,
            .func = NULL,
            .argtable = NULL,
            .func_w_context = [](void *context,int argc, char** argv) -> int {
                uint8_t mac[6];
                esp_read_mac(mac, ESP_MAC_WIFI_STA);
                printf("wifi_sta_mac: " MACSTR "\n", MAC2STR(mac));
                esp_read_mac(mac, ESP_MAC_WIFI_SOFTAP);
                printf("wifi_softap_mac: " MACSTR "\n", MAC2STR(mac));
                esp_read_mac(mac, ESP_MAC_BT);
                printf("bt_mac: " MACSTR "\n", MAC2STR(mac));
                return 0;
            },
            .context =this
        };
        ESP_ERROR_CHECK(esp_console_cmd_register(&cmd5));

        const esp_console_cmd_t cmd6 = {
            .command = "version",
            .help = "Read version info",
            .hint = NULL,
            .func = NULL,
            .argtable = NULL,
            .func_w_context = [](void *context,int argc, char** argv) -> int {
                auto self = static_cast<SensecapWatcher*>(context);
                auto app_desc = esp_app_get_description();
                const char* region = "UNKNOWN";
                #if defined(CONFIG_LANGUAGE_ZH_CN)
                    region = "CN";
                #elif defined(CONFIG_LANGUAGE_EN_US)
                    region = "US";
                #elif defined(CONFIG_LANGUAGE_JA_JP)
                    region = "JP";
                #elif defined(CONFIG_LANGUAGE_ES_ES)
                    region = "ES";
                #elif defined(CONFIG_LANGUAGE_DE_DE)
                    region = "DE";
                #elif defined(CONFIG_LANGUAGE_FR_FR)
                    region = "FR";
                #elif defined(CONFIG_LANGUAGE_IT_IT)
                    region = "IT";
                #elif defined(CONFIG_LANGUAGE_PT_PT)
                    region = "PT";
                #elif defined(CONFIG_LANGUAGE_RU_RU)
                    region = "RU";
                #elif defined(CONFIG_LANGUAGE_KO_KR)
                    region = "KR";
                #endif
                printf("{\"type\":0,\"name\":\"VER?\",\"code\":0,\"data\":{\"software\":\"%s\",\"hardware\":\"watcher xiaozhi agent\",\"camera\":%d,\"region\":\"%s\"}}\n",
                       app_desc->version,
                       self->GetCamera() == nullptr ? 0 : 1,
                       region);
                return 0;
            },
            .context =this
        };
        ESP_ERROR_CHECK(esp_console_cmd_register(&cmd6));

        esp_console_dev_uart_config_t hw_config = ESP_CONSOLE_DEV_UART_CONFIG_DEFAULT();
        ESP_ERROR_CHECK(esp_console_new_repl_uart(&hw_config, &repl_config, &repl));
        ESP_ERROR_CHECK(esp_console_start_repl(repl));
    }

    void InitializeCamera() {

        ESP_LOGI(TAG, "Initialize Camera");

        // !!!NOTE: SD Card use same SPI bus as sscma client, so we need to disable SD card CS pin first
        const gpio_config_t io_config = {
            .pin_bit_mask = (1ULL << BSP_SD_SPI_CS),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_ENABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE,
        };
        esp_err_t ret = gpio_config(&io_config);
        if (ret != ESP_OK)
            return;

        gpio_set_level(BSP_SD_SPI_CS, 1);

        camera_ = new SscmaCamera(io_exp_handle);
    }

public:
    // HMB|TEC Persona Light: GPIO43 LED test; do not use GPIO47/48 (I2C).
    static void PersonaLightTest(void*){
        led_strip_config_t strip_config = {};
        strip_config.strip_gpio_num = GPIO_NUM_43;
        strip_config.max_leds = 1;
        strip_config.led_model = LED_MODEL_WS2812;
        strip_config.color_component_format = LED_STRIP_COLOR_COMPONENT_FMT_GRB;
        led_strip_rmt_config_t rmt_config = {};
        rmt_config.clk_src = RMT_CLK_SRC_DEFAULT;
        rmt_config.resolution_hz = 10000000;
        rmt_config.mem_block_symbols = 64;
        led_strip_handle_t strip = nullptr;
        esp_err_t err = led_strip_new_rmt_device(&strip_config, &rmt_config, &strip);
        if(err != ESP_OK){
            ESP_LOGE(TAG, "Persona Light: RMT init failed: %s", esp_err_to_name(err));
            vTaskDelete(nullptr);
            return;
        }
        const uint8_t colors[][3] = {{32,0,0},{0,32,0},{0,0,32},{0,0,0}};
        ESP_LOGI(TAG, "Persona Light: GPIO43 test started");
        while(true){
            for(const auto &c : colors){
                led_strip_set_pixel(strip, 0, c[0], c[1], c[2]);
                led_strip_refresh(strip);
                vTaskDelay(pdMS_TO_TICKS(1000));
            }
        }
    }

    // HMB|TEC V0.3.17: Detection only triggers the existing XiaoZhi MCP flow.
    // No Capture()/Explain() here: vision credentials belong to the server session.
    static void SemanticLightTask(void* context) {
        (void)context;
        bool armed = true;
        uint32_t finish_handled = 0;
        bool finish_speaking_sent = false;
        bool finish_listening_sent = false;
        bool finish_cycle_started = false;
        int64_t finish_started_us = 0;
        int64_t finish_last_action_us = 0;
        int64_t presence_since = 0;
        int64_t absent_since = 0;
        for (;;) {
            const int64_t now = esp_timer_get_time();
            // Persona auto-finish: execute the SAME state-dependent operation as
            // the physical button, but never toggle while IDLE (would open chat).
            // Start only after the structured light scene has been received.
            const uint32_t request = hmb_persona_finish_request.load(std::memory_order_acquire);
            if (request != finish_handled) {
                finish_handled = request;
                // Duplicate MCP results must not restart a running finish cycle.
                if (!finish_cycle_started && !armed) {
                    finish_cycle_started = true;
                    finish_speaking_sent = false;
                    finish_listening_sent = false;
                    finish_started_us = now;
                    finish_last_action_us = 0;
                    ESP_LOGI(TAG, "PERSONA FINISH: started, request=%lu", (unsigned long)request);
                } else {
                    ESP_LOGI(TAG, "PERSONA FINISH: duplicate/unsolicited scene, request=%lu", (unsigned long)request);
                }
            }
            if (finish_started_us != 0) {
                const auto state = Application::GetInstance().GetDeviceState();
                // Allow MCP response to leave the server before interrupting TTS.
                if (now - finish_started_us >= 1000000LL &&
                    now - finish_started_us < 15000000LL &&
                    (finish_last_action_us == 0 || now - finish_last_action_us >= 600000LL)) {
                    if (state == kDeviceStateSpeaking && !finish_speaking_sent) {
                        finish_speaking_sent = true;
                        finish_last_action_us = now;
                        ESP_LOGI(TAG, "PERSONA FINISH: abort speaking");
                        HmbPersonaRequestFinish();
                    } else if (state == kDeviceStateListening && !finish_listening_sent) {
                        finish_listening_sent = true;
                        finish_last_action_us = now;
                        ESP_LOGI(TAG, "PERSONA FINISH: close listening channel");
                        HmbPersonaRequestFinish();
                    }
                }
                if (state == kDeviceStateIdle && now - finish_started_us >= 1000000LL) {
                    ESP_LOGI(TAG, "PERSONA FINISH: idle reached");
                    finish_started_us = 0;
                } else if (now - finish_started_us >= 15000000LL) {
                    ESP_LOGW(TAG, "PERSONA FINISH: timeout, no forced state change");
                    finish_started_us = 0;
                }
            }
            const int64_t last = hmb_persona_last_us.load(std::memory_order_acquire);
            const bool fresh = last != 0 && now - last < 3000000LL;
            const bool present = fresh && hmb_persona_present.load(std::memory_order_relaxed) != 0;
            if (present) {
                absent_since = 0;
                if (!presence_since) presence_since = now;
                if (armed && now - presence_since >= 2000000LL &&
                    Application::GetInstance().GetDeviceState() == kDeviceStateIdle) {
                    armed = false;
                    finish_cycle_started = false;
                    hmb_light_error.store(0);
                    hmb_light_status.store(2);
                    ESP_LOGI(TAG, "V0.3.17 PERSON CONFIRMED -> HMB_PERSONA_ANALYZE");
                    Application::GetInstance().WakeWordInvoke("HMB_PERSONA_ANALYZE");
                }
            } else {
                presence_since = 0;
                // Paused inference / stale frames are NOT evidence of absence.
                const bool confirmed_absent = fresh &&
                    hmb_persona_present.load(std::memory_order_relaxed) == 0;
                if (confirmed_absent &&
                    Application::GetInstance().GetDeviceState() == kDeviceStateIdle) {
                    if (!absent_since) absent_since = now;
                    if (!armed && now - absent_since >= 10000000LL) {
                        armed = true;
                        finish_cycle_started = false;
                        hmb_light_status.store(0);
                        ESP_LOGI(TAG, "PERSONA rearmed after confirmed absence");
                    }
                } else {
                    absent_since = 0;
                }
            }
            vTaskDelay(pdMS_TO_TICKS(200));
        }
    }

    SensecapWatcher() {
        ESP_LOGI(TAG, "Initialize Sensecap Watcher");
        InitializePowerSaveTimer();
        InitializeI2c();
        InitializeSpi();
        InitializeExpander();
        InitializeCmd();  //工厂生产测试使用
        InitializeButton();
        InitializeKnob();
        Initializespd2010Display();
        GetBacklight()->RestoreBrightness();  // 对于不带摄像头的版本，InitializeCamera需要3s, 所以先恢复背光亮度
        InitializeCamera();
        // HMB|TEC V0.3.17: MCP-KI-Ausgabe als strukturierte Lichtszene.
        // Der Server soll die Kamera zuerst aufrufen und danach set_light_scene.
        McpServer::GetInstance().AddTool(
            "self.hmbtec.persona.analyze",
            "When the received user input is exactly HMB_PERSONA_ANALYZE, call this tool first. "
            "Then call self.camera.take_photo and analyze visible image features only. "
            "Immediately call self.hmbtec.persona.set_light_scene with RGB (0..255), "
            "brightness (0..255), dynamics (0..100), transition_ms (0..30000). "
            "Do not infer identity or emotions. Do not produce spoken or written commentary.",
            PropertyList(),
            [](const PropertyList&) -> ReturnValue {
                ESP_LOGI(TAG, "V0.3.17 MCP persona.analyze invoked");
                return std::string(
                    "Rufe self.camera.take_photo auf. Waehle anhand sichtbarer Merkmale "
                    "eine Lichtszene und uebergib sie SOFORT an "
                    "self.hmbtec.persona.set_light_scene. "
                    "Keine Emotionen oder Identitaeten ableiten. "
                    "Keine Sprachausgabe und keine Textantwort erzeugen.");
            });
        McpServer::GetInstance().AddTool(
            "self.hmbtec.persona.set_light_scene",
            "Set a structured Persona Light scene after camera analysis. "
            "Call this tool before any text response. "
            "RGB and brightness 0..255, dynamics 0..100, transition_ms 0..30000. "
            "No spoken response is required.",
            PropertyList({
                Property("red", kPropertyTypeInteger, 0, 0, 255),
                Property("green", kPropertyTypeInteger, 0, 0, 255),
                Property("blue", kPropertyTypeInteger, 0, 0, 255),
                Property("brightness", kPropertyTypeInteger, 128, 0, 255),
                Property("dynamics", kPropertyTypeInteger, 20, 0, 100),
                Property("transition_ms", kPropertyTypeInteger, 2000, 0, 30000)
            }),
            [](const PropertyList& properties) -> ReturnValue {
                const int r = properties["red"].value<int>();
                const int g = properties["green"].value<int>();
                const int b = properties["blue"].value<int>();
                const int brightness = properties["brightness"].value<int>();
                const int dynamics = properties["dynamics"].value<int>();
                const int transition = properties["transition_ms"].value<int>();
                hmb_light_r.store(r);
                hmb_light_g.store(g);
                hmb_light_b.store(b);
                hmb_light_brightness.store(brightness);
                hmb_light_dynamics.store(dynamics);
                hmb_light_transition.store(transition);
                hmb_artnet_scene_ready.store(true, std::memory_order_release);
                hmb_light_status.store(3);
                hmb_persona_finish_request.fetch_add(1, std::memory_order_release);
                ESP_LOGI(TAG, "V0.3.17 LIGHT_SCENE RGB=%d,%d,%d BRIGHT=%d DYN=%d TRANSITION=%dms",
                         r, g, b, brightness, dynamics, transition);
                return std::string("{\"ok\":true,\"scene_applied\":true,\"message\":\"Scene queued for Art-Net broadcast (requires connected Wi-Fi)\"}");
            });
        if (xTaskCreate(HmbArtNetTask, "hmb_artnet", 4096, nullptr, 2, nullptr) != pdPASS) {
            ESP_LOGE(TAG, "PERSONA ARTNET: task creation failed");
        }
        if (xTaskCreate(SemanticLightTask, "semantic_light", 8192, this, 2, nullptr) != pdPASS) {
            ESP_LOGE(TAG, "V0.3.17 semantic task creation failed");
        }
        // Disable this task if GPIO43 is used by another device/console.
        if(xTaskCreate(PersonaLightTest, "persona_light", 4096, nullptr, 2, nullptr) != pdPASS){
            ESP_LOGE(TAG, "Persona Light: task creation failed");
        }
    }

    virtual AudioCodec* GetAudioCodec() override {
        static SensecapAudioCodec audio_codec(
            i2c_bus_, 
            AUDIO_INPUT_SAMPLE_RATE, 
            AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_GPIO_MCLK, 
            AUDIO_I2S_GPIO_BCLK, 
            AUDIO_I2S_GPIO_WS, 
            AUDIO_I2S_GPIO_DOUT, 
            AUDIO_I2S_GPIO_DIN,
            AUDIO_CODEC_PA_PIN, 
            AUDIO_CODEC_ES8311_ADDR, 
            AUDIO_CODEC_ES7243E_ADDR, 
            AUDIO_INPUT_REFERENCE);
        // Akustische Ausgabe stumm; die MCP-Sitzung bleibt erhalten.
        audio_codec.SetOutputVolume(0);
        return &audio_codec;
    }

    virtual Display* GetDisplay() override {
        return display_;
    }
    
    virtual Backlight* GetBacklight() override {
        static PwmBacklight backlight(DISPLAY_BACKLIGHT_PIN, DISPLAY_BACKLIGHT_OUTPUT_INVERT);
        return &backlight;
    }

    // 根据 https://github.com/Seeed-Studio/OSHW-SenseCAP-Watcher/blob/main/Hardware/SenseCAP_Watcher_v1.0_SCH.pdf
    // RGB LED型号为 ws2813 mini, 连接在GPIO 40，供电电压 3.3v, 没有连接 BIN 双信号线
    // 可以直接兼容SingleLED采用的ws2812
    virtual Led* GetLed() override {
        static SingleLed led(BUILTIN_LED_GPIO);
        return &led;
    }

    virtual void SetPowerSaveLevel(PowerSaveLevel level) override {
        if (level != PowerSaveLevel::LOW_POWER) {
            power_save_timer_->WakeUp();
        }
        WifiBoard::SetPowerSaveLevel(level);
    }

    virtual bool GetBatteryLevel(int& level, bool& charging, bool& discharging) override {
        charging = (IoExpanderGetLevel(BSP_PWR_VBUS_IN_DET) == 0);
        discharging = !charging;
        level = (int)BatterygetPercent(false);

        // Always synchronize, including the first snapshot and a short USB
        // connection observed only by the shutdown callback. Re-enabling is a no-op.
        power_save_timer_->SetEnabled(discharging);
        if (level <= 1  &&  discharging) {
            ESP_LOGI(TAG, "Battery level is low, shutting down");
            IoExpanderSetLevel(BSP_PWR_SYSTEM, 0);
        }
        return true;
    }

    virtual Camera* GetCamera() override {
        return camera_;
    }
};

DECLARE_BOARD(SensecapWatcher);

// 定义静态成员变量
SensecapWatcher* SensecapWatcher::instance_ = nullptr;
