HMB|TEC Persona Light V0.3.25
Art-Net Universe 0, UDP Broadcast 255.255.255.255:6454
Startup CH1..6 unveraendert.
Patch ueber V0.3.24 installieren.
