HMB|TEC Persona Light V0.3.18 – UI-Statusbereinigung
Basis: V0.3.17 (funktionierende Bildanalyse und MCP-Lichtparameter).
Änderung: NUR Status-Texte in main/application.cc (HandleStateChangedEvent):
Idle=BEREIT, Connecting=KI VERBINDET, Listening=KI ANALYSIERT,
Speaking/Notifying=LICHTSZENE AKTIV.
Kein Eingriff in XiaoZhi-Zustandsmaschine, Audio, Kamera oder MCP.
Der bestehende Persona-Light-RGB-Bildschirm bleibt unverändert.
Der Installer patcht die aktuelle application.cc vor Ort, statt eine alte Version zu überschreiben.
Hinweis: Andere Textausgaben (z.B. TTS-Chat) werden hier nicht verändert.
Nicht auf ESP-IDF-Hardware getestet.
