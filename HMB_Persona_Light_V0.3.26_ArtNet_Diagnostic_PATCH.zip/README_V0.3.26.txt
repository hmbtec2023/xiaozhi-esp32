HMB | TEC Persona Light V0.3.26 - Art-Net Diagnose
Basis: V0.3.25; enthaelt die bisherige Kameralogik.
Broadcast 192.168.178.255:6454, Universe 0, 20 Hz.
Startup: 0 -> CH1..CH6 einzeln 255 -> 0.
Diagnose: Task angelegt/gestartet, WLAN, Socket, erstes Paket, sendto-Fehler.
Voraussetzung: Netz 192.168.178.0/24 und kein WLAN Client-Isolation.
Installation: unzip -o ... 'main/*'; idf.py build; Version im Binary pruefen; flash.
Nicht auf Zielhardware kompiliert/getestet.
